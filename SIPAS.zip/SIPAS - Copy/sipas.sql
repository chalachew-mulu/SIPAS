-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2019 at 10:46 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sipas`
--

-- --------------------------------------------------------

--
-- Table structure for table `acceptance_status`
--

CREATE TABLE `acceptance_status` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `acceptance_status`
--

INSERT INTO `acceptance_status` (`id`, `name`) VALUES
(1, 'Accepted'),
(2, 'Pending..'),
(3, 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `advisor`
--

CREATE TABLE `advisor` (
  `id` int(11) NOT NULL,
  `advisor_id` varchar(30) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `officeNumber` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `is_assigned_for_student` varchar(10) DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `advisor`
--

INSERT INTO `advisor` (`id`, `advisor_id`, `firstname`, `lastname`, `mobile`, `faculty`, `officeNumber`, `email`, `qualification`, `is_assigned_for_student`) VALUES
(1, '121', 'lemas', 'kebede', '76', 'Faculty of Computing', '23', 'abcd@gmail.com', 'Networking', 'yes'),
(2, 'bdu987654', 'mintesnot', 'abebe', '098765342', 'Faculty of Computing', '098', 'cjsdf@dmah.com', 'Networking', 'no'),
(3, 'BDU070987635UR', 'achamyeleh', 'belete', '0987635423', 'Faculty of Industrial and Mechanical Engineering', '8978', 'achamyeleh@gmail.com', 'Programming', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE `announcement` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `start_date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `date_posted` date NOT NULL,
  `posted_by` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`id`, `name`, `description`, `start_date`, `expiry_date`, `date_posted`, `posted_by`) VALUES
(13, 'announcement 1', 'we are glad to tell all of poly faculty dean. so lets register with this specified tim ', '2019-06-11', '2019-10-25', '2019-06-09', 'admin'),
(14, 'announcement 2', 'please give minimum time of 2 hourses of practical work for internship student', '2019-06-21', '2019-08-12', '2019-06-09', 'Coordinator'),
(15, 'announcement 3', 'for all comuting faculty students time for presentation will helled ', '2019-06-21', '2019-08-08', '2019-06-09', 'Faculty');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `companyName` varchar(100) NOT NULL,
  `website` varchar(100) NOT NULL,
  `region` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `fax` varchar(100) NOT NULL,
  `zone` varchar(100) NOT NULL,
  `kebele` varchar(100) NOT NULL,
  `capacity` int(11) NOT NULL,
  `reserved` int(11) NOT NULL,
  `description` text,
  `photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `companyName`, `website`, `region`, `city`, `email`, `fax`, `zone`, `kebele`, `capacity`, `reserved`, `description`, `photo`) VALUES
(12, 'Amhara Pipe Factory', 'https://www.amapiipe.com', 'Amhara', 'BahirDar', 'amma@gmail.com', '45623', 'BahirDar', ' Alcan 15', 128, 1, '                                                                                                                                                                                                                                                                                                                           Amahara Pipe Factory is on of the best and trustful media that provides accurate, on demand timely information\'s for Ethiopian people. for the sake of hiring experienced employee we provide internship training for high school student every year \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  ', '16406423_954482581319623_8110234388212073164_n.jpg'),
(13, 'CISCO Lab', 'www.cisco.com', 'Addis Ababa', 'Addis Ababa', 'cisco@gmail.com', '45620', 'Addis Ababa', 'Nfas Slk ', 45, 0, '                                                                                                                                                   CISCO Lab is on of the best and trustful media that provides accurate, on demand timely information\'s for Ethiopian people. for the sake of hiring experienced employee we provide internship training for high school student every year \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  ', 'city_lights_lights_road_cars_buildings_58573_3840x2400.jpg'),
(19, 'Amhara Mass Media Agency', 'www.amma.com', 'Amhara', 'BahirDar', 'amma@gmail.com', '45623', 'BahirDar', 'Geter Menger 13', 121, 1, '                                                                                                                                                                                             Amhara mass media agency is on of the best and trustful media that provides accurate, on demand timely information\'s for Ethiopian people. for the sake of hiring experienced employee we provide internship training for high school student every year \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  ', 'eco_city-wallpaper-5120x2880.jpg'),
(20, 'INSA', 'www.insa.com', 'Addis Ababa', 'Addis Ababa', 'insa@gmail.com', '45623', 'Addis Ababa', 'Mercato', 65, 0, '                                                                                                         INSA is on of the best and trustful media that provides accurate, on demand timely information\'s for Ethiopian people. for the sake of hiring experienced employee we provide internship training for high school student every year \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  ', 'graphics_low_poly_digital_art_minimalism_102027_3840x2160.jpg'),
(21, 'Cyber Soft', 'www.cyber.com', 'Addis Ababa', 'Addis Ababa', 'cyber@gmail.com', '4562', 'Addis Ababa', 'Mexico', 54, 0, '                                                                                                                                                   Cyber Soft is on of the best and trustful media that provides accurate, on demand timely information\'s for Ethiopian people. for the sake of hiring experienced employee we provide internship training for high school student every year \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  ', 'laptop_management_server_administration_3d_graphics_80026_3000x2250.jpg'),
(22, 'I COG LAB', 'www.icog.com', 'Addis Ababa', 'Addis Ababa', 'icog@gmail.com', '45623', 'Addis Ababa', 'Piasa', 20, 0, '                                                                                                         I COG LAB is on of the best and trustful media that provides accurate, on demand timely information\'s for Ethiopian people. for the sake of hiring experienced employee we provide internship training for high school student every year \r\n                  \r\n                  \r\n                  \r\n                  \r\n                  ', 'intern.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `coordinator`
--

CREATE TABLE `coordinator` (
  `id` int(11) NOT NULL,
  `Coordinator_id` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `officeNo` varchar(20) NOT NULL,
  `company_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `coordinator`
--

INSERT INTO `coordinator` (`id`, `Coordinator_id`, `firstname`, `lastname`, `email`, `mobile`, `officeNo`, `company_id`) VALUES
(3, 'cord10', 'Alemayehu', 'Kbebu', 'alem@gmail.com', '0934213234', '98', 12),
(4, 'cord11', 'Tewodros', 'Abebaw', 'tewodros11@gmail.com', '0976524314', '54', 13),
(5, 'cord12', 'Zemenay', 'Kibru', 'zemenay12@yahoo.com', '0987245122', '34', 19);

-- --------------------------------------------------------

--
-- Table structure for table `coordinator_assign_supervisor`
--

CREATE TABLE `coordinator_assign_supervisor` (
  `id` int(11) NOT NULL,
  `supervisor_id` varchar(20) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `date_assigned` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `coordinator_assign_supervisor`
--

INSERT INTO `coordinator_assign_supervisor` (`id`, `supervisor_id`, `student_id`, `date_assigned`) VALUES
(1, 'super11', 'BDU0702338UR', '2019-06-12 02:35:52'),
(2, 'super11', 'BDU0701536UR', '2019-06-12 02:35:52'),
(3, 'super11', 'BDU0702313UR', '2019-06-12 02:35:52');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `faculty_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`, `faculty_id`) VALUES
(8, 'Software Engineering', 1),
(9, 'Computer Science', 1),
(10, 'Electrical Engineering', 2),
(11, 'Mechanical Engineering', 3),
(12, 'Information System', 1),
(13, 'Computer Engineering', 2),
(14, 'Information Technology', 1),
(15, 'Industrial Engineering', 3);

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`) VALUES
(1, 'Faculty of Computing'),
(2, 'Faculty of Electrical and Computer Engineering'),
(3, 'Faculty of Mechanical and Industrial Engineering'),
(4, 'Faculty of Civil and Water Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_assign_advisor`
--

CREATE TABLE `faculty_assign_advisor` (
  `id` int(11) NOT NULL,
  `advisor_id` varchar(50) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `date_assigned` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty_assign_advisor`
--

INSERT INTO `faculty_assign_advisor` (`id`, `advisor_id`, `student_id`, `date_assigned`) VALUES
(1, '121', 'BDU0701538UR', '2019-06-12 00:53:17'),
(2, '121', 'BDU0702338UR', '2019-06-12 00:53:17'),
(3, '121', 'BDU0702313UR', '2019-06-12 00:53:17');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_dean`
--

CREATE TABLE `faculty_dean` (
  `id` int(11) NOT NULL,
  `facultyDeanID` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(25) NOT NULL,
  `officeNumber` varchar(25) NOT NULL,
  `faculty` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty_dean`
--

INSERT INTO `faculty_dean` (`id`, `facultyDeanID`, `firstname`, `lastname`, `email`, `mobile`, `officeNumber`, `faculty`) VALUES
(85, 'bdu2464', 'geremew', 'zelaki', 'asd@dfndnf.com', '6879', '65', 'Faculty of Computing'),
(86, 'bdu098654', 'chalachew', 'lastname', 'admin@admin.com', '09876543', '454', 'Faculty of Computing'),
(94, 'bdu1234urre', 'abebe', 'kebeb', 'admin@admin.com', '233', '4545', 'Faculty of Computing'),
(118, 'bdu1234uras', 'yohannes', 'sefanes', 'jonaldsefane@gmail.com', '0987653412', '98', 'Faculty of Computing'),
(119, '12', 'yohannes', 'mulu', 'abcd@gmail.com', '0987653412', '4545', 'Faculty of Computing'),
(120, 'Dean14', 'kebede', 'lema', 'kebede@gmail.com', '0987645312', '76', 'Faculty of Mechanical and Industrial Engineering'),
(121, 'Dean15', 'civil', 'civil', 'civil@gmail.com', '0987635423', '76', 'Faculty of Civil and Water Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `internship_request`
--

CREATE TABLE `internship_request` (
  `id` int(11) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `ac_status` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `duration` varchar(50) DEFAULT NULL,
  `description` text,
  `date_requested` datetime DEFAULT NULL,
  `date_responsed` varchar(50) DEFAULT NULL,
  `is_supervisor_assigned` varchar(5) NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `internship_request`
--

INSERT INTO `internship_request` (`id`, `student_id`, `comp_id`, `ac_status`, `start_date`, `end_date`, `duration`, `description`, `date_requested`, `date_responsed`, `is_supervisor_assigned`) VALUES
(52, 'BDU0701538UR', 19, 1, '2019-06-09', '2019-06-09', '61 Days', 'i wanna to apply my two month delay of internship in your company.. ', '2019-06-08 10:57:44', '2019-06-08 11:30:54.564', 'no'),
(57, 'BDU0701536UR', 12, 1, '2020-03-19', '2020-03-19', '62 Days', 'hi am gashaw negash from addis abab university depatment of information system', '2019-06-08 11:20:32', '2019-06-08 11:29:32.325', 'yes'),
(66, 'BDU0702313UR', 12, 1, '2019-06-22', '2019-09-20', '90 Days', NULL, NULL, NULL, 'yes'),
(67, 'BDU0702338UR', 12, 1, '2019-06-22', '2019-09-20', '90 Days', NULL, NULL, NULL, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `reciever_id` int(11) NOT NULL,
  `notification` text NOT NULL,
  `send_time` datetime NOT NULL,
  `recieve_time` datetime NOT NULL,
  `isread` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `sipas_user`
--

CREATE TABLE `sipas_user` (
  `id` int(11) NOT NULL,
  `role` varchar(30) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL,
  `cord_id` int(11) DEFAULT NULL,
  `dean_id` int(11) DEFAULT NULL,
  `advisor_id` int(11) DEFAULT NULL,
  `super_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sipas_user`
--

INSERT INTO `sipas_user` (`id`, `role`, `username`, `password`, `status`, `cord_id`, `dean_id`, `advisor_id`, `super_id`) VALUES
(91, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Active', NULL, NULL, NULL, NULL),
(121, 'Faculty', 'user', 'd781eaae8248db6ce1a7b82e58e60435', 'Active', NULL, 94, NULL, NULL),
(122, 'Coordinator', 'coordinator', 'c4312c2a07bf7ded608a4d7cee2228dd', 'Active', 3, NULL, NULL, NULL),
(123, 'Coordinator', 'cord12', '2ceb56d97bb6e0e3ac7bcdc81383bfa2', 'Active', 4, NULL, NULL, NULL),
(124, 'Coordinator', 'cord13', '8b7a90ae27ff6a4781674a3867ddf686', 'Active', 5, NULL, NULL, NULL),
(127, 'Advisor', 'advisor', 'a33c7303d4bc3322700a0f53787677c5', 'Active', NULL, NULL, 1, NULL),
(128, 'Advisor', 'advisor1', 'f00fea67eaa512cbd06954ac3db46e63', 'Active', NULL, NULL, 2, NULL),
(129, 'Supervisor', 'super10', 'fc9f06581ec16c3965d30dfb0ef37401', 'Active', NULL, NULL, NULL, 3),
(130, 'Supervisor', 'super11', '5d2e7856bb154101615a0a4b01a486de', 'Active', NULL, NULL, NULL, 4),
(131, 'Faculty', 'civil12', '353045028b48c69d5d6b6bf183ea03c5', 'Active', NULL, 121, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `studID` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `grandfather` varchar(50) NOT NULL,
  `mothername` varchar(100) NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `department` varchar(100) NOT NULL,
  `faculty` varchar(100) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `is_advisor_assigned` varchar(10) DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `studID`, `firstname`, `lastname`, `grandfather`, `mothername`, `mobile`, `email`, `year`, `department`, `faculty`, `username`, `password`, `is_advisor_assigned`) VALUES
(7, 'BDU0701538UR', 'chalachew', 'mulu', 'chanie', 'tobiaw', '0946098413', 'chalachewmulu@gmail.com', '5', 'Software Engineering', 'Faculty of Computing', 'BDU0701538UR', 'aef2f1db1888a22238362313cb062741', 'yes'),
(9, 'BDU0702338UR', 'yohannes', 'sefane', 'mola', 'ataklt', '0943052128', 'jonaldsefane@gmail.com', '5', 'Computer Science', 'Faculty of Computing', 'BDU0702338UR', 'd7674ffabf9ab2ba53c171882759a2d2', 'yes'),
(10, 'BDU0701536UR', 'gashaw', 'negash', 'chanie', 'wubalu', '0923456738', 'gashsawnegash@gmail.com', '5', 'Information System', 'Faculty of Computing', 'BDU0701536UR', '2273d2095294f9753807f024bfab17f6', 'no'),
(11, 'BDU0702313UR', 'tefera', 'addis', 'tewodros', 'alemitu', '0918324569', 'teferaaddis@gmail.com', '5', 'Software Engineering', 'Faculty of Computing', 'BDU0702313UR', 'be7029d46b738e393e883824ec7f6e9a', 'yes'),
(12, 'BDU0702330UR', 'mekdes', 'fitgu', 'asnakew', 'zebader', '0945608934', 'mekdes@gmail.com', '5', 'Software Engineering', 'Faculty of Computing', 'BDU0701538UR', '9ed0a191bf98a1e5e6ef55d5105a1646', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE `student_attendance` (
  `id` int(11) NOT NULL,
  `student_id` varchar(50) DEFAULT 'empty',
  `status` varchar(20) NOT NULL DEFAULT 'not defined',
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student_attendance`
--

INSERT INTO `student_attendance` (`id`, `student_id`, `status`, `date`) VALUES
(1, 'BDU0701536UR', 'Present', '2019-06-21'),
(4, 'BDU0702313UR', 'Present', '2019-06-21'),
(5, 'BDU0702338UR', 'Abcent', '2019-06-21');

-- --------------------------------------------------------

--
-- Table structure for table `student_grade`
--

CREATE TABLE `student_grade` (
  `id` int(11) NOT NULL,
  `number_grade` float NOT NULL,
  `letter_grade` varchar(5) NOT NULL,
  `student_id` varchar(50) NOT NULL,
  `submit_by_id` varchar(50) NOT NULL,
  `date_submitted` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student_grade`
--

INSERT INTO `student_grade` (`id`, `number_grade`, `letter_grade`, `student_id`, `submit_by_id`, `date_submitted`) VALUES
(1, 91.2, 'A+', 'BDU0702338UR', '121', '2019-06-12');

-- --------------------------------------------------------

--
-- Table structure for table `student_result`
--

CREATE TABLE `student_result` (
  `id` int(11) NOT NULL,
  `student_id` varchar(30) NOT NULL,
  `score` float NOT NULL,
  `result_submit_date` date NOT NULL,
  `result_submit_by_super_id` varchar(30) DEFAULT NULL,
  `result_submit_by_adv_id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student_result`
--

INSERT INTO `student_result` (`id`, `student_id`, `score`, `result_submit_date`, `result_submit_by_super_id`, `result_submit_by_adv_id`) VALUES
(1, 'BDU0702338UR', 28.2, '2019-06-12', 'super11', NULL),
(2, 'BDU0702338UR', 63, '2019-06-12', NULL, '121');

-- --------------------------------------------------------

--
-- Table structure for table `supervisor`
--

CREATE TABLE `supervisor` (
  `id` int(11) NOT NULL,
  `super_id` varchar(30) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobile` varchar(30) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `is_assigned_for_student` varchar(5) NOT NULL DEFAULT 'no'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `supervisor`
--

INSERT INTO `supervisor` (`id`, `super_id`, `firstname`, `lastname`, `email`, `mobile`, `qualification`, `comp_id`, `is_assigned_for_student`) VALUES
(3, 'super10', 'Esleman', 'Yesuf', 'esleman@gmail.com', '095423165', 'Programming', 12, 'no'),
(4, 'super11', 'Sewunet', 'Belay', 'sewunet@gmail.com', '0954132456', 'Design', 12, 'yes'),
(5, 'super12', 'Alemken', 'Belayneh', 'alem@gmail.com', '0954234125', 'Maintenance', 12, 'no'),
(6, 'super14', 'Belete', 'Belay', 'super12@gmail.com', '098736523', 'Networking', 12, 'no');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acceptance_status`
--
ALTER TABLE `acceptance_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advisor`
--
ALTER TABLE `advisor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `advisor_id` (`advisor_id`);

--
-- Indexes for table `announcement`
--
ALTER TABLE `announcement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD PRIMARY KEY (`id`),
  ADD KEY `company_id` (`company_id`);

--
-- Indexes for table `coordinator_assign_supervisor`
--
ALTER TABLE `coordinator_assign_supervisor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supervisor_id` (`supervisor_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fuculty_id` (`faculty_id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_assign_advisor`
--
ALTER TABLE `faculty_assign_advisor`
  ADD PRIMARY KEY (`id`),
  ADD KEY `advisor_id` (`advisor_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `faculty_dean`
--
ALTER TABLE `faculty_dean`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `facultyDeanID` (`facultyDeanID`);

--
-- Indexes for table `internship_request`
--
ALTER TABLE `internship_request`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comp_id` (`comp_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `ac_status` (`ac_status`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sipas_user`
--
ALTER TABLE `sipas_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `cord_id` (`cord_id`),
  ADD KEY `dean_id` (`dean_id`),
  ADD KEY `advisor_id` (`advisor_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `studID` (`studID`),
  ADD KEY `department` (`department`),
  ADD KEY `faculty` (`faculty`);

--
-- Indexes for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_attendance_ibfk_1` (`student_id`);

--
-- Indexes for table `student_grade`
--
ALTER TABLE `student_grade`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `submit_bi_id` (`submit_by_id`);

--
-- Indexes for table `student_result`
--
ALTER TABLE `student_result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `result_submit_by` (`result_submit_by_super_id`),
  ADD KEY `result_submit_by_adv_id` (`result_submit_by_adv_id`);

--
-- Indexes for table `supervisor`
--
ALTER TABLE `supervisor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `super_id` (`super_id`),
  ADD KEY `comp_id` (`comp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acceptance_status`
--
ALTER TABLE `acceptance_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `advisor`
--
ALTER TABLE `advisor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `announcement`
--
ALTER TABLE `announcement`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `coordinator`
--
ALTER TABLE `coordinator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `coordinator_assign_supervisor`
--
ALTER TABLE `coordinator_assign_supervisor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `faculty_assign_advisor`
--
ALTER TABLE `faculty_assign_advisor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `faculty_dean`
--
ALTER TABLE `faculty_dean`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `internship_request`
--
ALTER TABLE `internship_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sipas_user`
--
ALTER TABLE `sipas_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=132;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `student_attendance`
--
ALTER TABLE `student_attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student_grade`
--
ALTER TABLE `student_grade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student_result`
--
ALTER TABLE `student_result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `supervisor`
--
ALTER TABLE `supervisor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD CONSTRAINT `coordinator_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`);

--
-- Constraints for table `coordinator_assign_supervisor`
--
ALTER TABLE `coordinator_assign_supervisor`
  ADD CONSTRAINT `coordinator_assign_supervisor_ibfk_1` FOREIGN KEY (`supervisor_id`) REFERENCES `supervisor` (`super_id`),
  ADD CONSTRAINT `coordinator_assign_supervisor_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `student` (`studID`);

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculty` (`id`);

--
-- Constraints for table `faculty_assign_advisor`
--
ALTER TABLE `faculty_assign_advisor`
  ADD CONSTRAINT `faculty_assign_advisor_ibfk_1` FOREIGN KEY (`advisor_id`) REFERENCES `advisor` (`advisor_id`),
  ADD CONSTRAINT `faculty_assign_advisor_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `student` (`studID`);

--
-- Constraints for table `internship_request`
--
ALTER TABLE `internship_request`
  ADD CONSTRAINT `internship_request_ibfk_2` FOREIGN KEY (`comp_id`) REFERENCES `company` (`id`),
  ADD CONSTRAINT `internship_request_ibfk_3` FOREIGN KEY (`student_id`) REFERENCES `student` (`studID`),
  ADD CONSTRAINT `internship_request_ibfk_4` FOREIGN KEY (`ac_status`) REFERENCES `acceptance_status` (`id`);

--
-- Constraints for table `sipas_user`
--
ALTER TABLE `sipas_user`
  ADD CONSTRAINT `sipas_user_ibfk_1` FOREIGN KEY (`cord_id`) REFERENCES `coordinator` (`id`),
  ADD CONSTRAINT `sipas_user_ibfk_2` FOREIGN KEY (`dean_id`) REFERENCES `faculty_dean` (`id`),
  ADD CONSTRAINT `sipas_user_ibfk_3` FOREIGN KEY (`advisor_id`) REFERENCES `advisor` (`id`),
  ADD CONSTRAINT `sipas_user_ibfk_4` FOREIGN KEY (`super_id`) REFERENCES `supervisor` (`id`);

--
-- Constraints for table `student_attendance`
--
ALTER TABLE `student_attendance`
  ADD CONSTRAINT `student_attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`studID`);

--
-- Constraints for table `student_grade`
--
ALTER TABLE `student_grade`
  ADD CONSTRAINT `student_grade_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`studID`),
  ADD CONSTRAINT `student_grade_ibfk_2` FOREIGN KEY (`submit_by_id`) REFERENCES `advisor` (`advisor_id`);

--
-- Constraints for table `student_result`
--
ALTER TABLE `student_result`
  ADD CONSTRAINT `student_result_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student` (`studID`),
  ADD CONSTRAINT `student_result_ibfk_2` FOREIGN KEY (`result_submit_by_super_id`) REFERENCES `supervisor` (`super_id`),
  ADD CONSTRAINT `student_result_ibfk_3` FOREIGN KEY (`result_submit_by_adv_id`) REFERENCES `advisor` (`advisor_id`);

--
-- Constraints for table `supervisor`
--
ALTER TABLE `supervisor`
  ADD CONSTRAINT `supervisor_ibfk_1` FOREIGN KEY (`comp_id`) REFERENCES `company` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
