package com.sipas.bean;
public class UILmanageUserBean {
private String userRole;
private String fullname;
private String username;
private String password;
private String repassword;
private String status;
public UILmanageUserBean() {
	super();
}
public UILmanageUserBean(String userRole, String fullname, String username, String password,
		String status) {
	super();
	this.userRole = userRole;
	this.fullname = fullname;
	this.username = username;
	this.password = password;
	this.status = status;
}

public String getUserRole() {
	return userRole;
}
public void setUserRole(String userRole) {
	this.userRole = userRole;
}
public String getFullname() {
	return fullname;
}
public void setFullname(String fullname) {
	this.fullname = fullname;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getRepassword() {
	return repassword;
}
public void setRepassword(String repassword) {
	this.repassword = repassword;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}

}
