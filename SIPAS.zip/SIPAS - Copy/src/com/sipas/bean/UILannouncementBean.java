package com.sipas.bean;

import java.util.Date;

public class UILannouncementBean {
private int id;	
private String name;
private Date datePosted;
private String description;
private Date startDate;
private Date endDate;
public UILannouncementBean() {
	super();
}
public UILannouncementBean(int id) {
	super();
	this.id = id;
}
public UILannouncementBean(String name, Date startDate, String description, Date posted, Date expiry) {
	super();
	this.name = name;
	this.datePosted = startDate;
	this.description = description;
	this.startDate = posted;
	this.endDate = expiry;
}
public UILannouncementBean(int id, String name, Date datePosted, String description, Date startDate, Date endDate) {
	super();
	this.id = id;
	this.name = name;
	this.datePosted = datePosted;
	this.description = description;
	this.startDate = startDate;
	this.endDate = endDate;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Date getDatePosted() {
	return datePosted;
}
public void setDatePosted(Date datePosted) {
	this.datePosted = datePosted;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public Date getStartDate() {
	return startDate;
}
public void setStartDate(Date startDate) {
	this.startDate = startDate;
}
public Date getEndDate() {
	return endDate;
}
public void setEndDate(Date endDate) {
	this.endDate = endDate;
}

}
