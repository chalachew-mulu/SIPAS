package com.sipas.bean;

public class UILmanageFacultyDeanBean {
	 private int id;
	 private String facultyDeanID;
	 private String firstname;
	 private String lastname;
	 private String email;
	 private String mobile;
	 private String officeNumber;
	 private String faculty;
	 
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFacultyDeanID() {
		return facultyDeanID;
	}
	public void setFacultyDeanID(String facultyDeanID) {
		this.facultyDeanID = facultyDeanID;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getOfficeNumber() {
		return officeNumber;
	}
	public void setOfficeNumber(String officeNumber) {
		this.officeNumber = officeNumber;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public UILmanageFacultyDeanBean() {
		super();
	}
	public UILmanageFacultyDeanBean(String facultyDeanID, String firstname, String lastname, String email, String officeNumber, String mobile, String faculty) {
		super();
		this.facultyDeanID = facultyDeanID;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.mobile = mobile;
		this.officeNumber = officeNumber;
		this.faculty = faculty;
	}
	public UILmanageFacultyDeanBean(int id, String facultyDeanID, String firstname, String lastname, String email, String mobile,String officeNumber, String faculty) {
		super();
		this.id = id;
		this.facultyDeanID = facultyDeanID;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.mobile = mobile;
		this.officeNumber = officeNumber;
		this.faculty = faculty;
	}
	@Override
	public String toString() {
		return "UILBean [id=" + id + ", facultyDeanID=" + facultyDeanID + ", firstname=" + firstname + ", lastname="
				+ lastname + ", email=" + email + ", mobile=" + mobile + ", officeNumber=" + officeNumber + ", faculty="
				+ faculty + "]";
	}

}

//User management class for UIL	
	 class manageUserBean{
		private String username;
		private String password;
		private String confirmPassword;
		private String role;
		private String status;
		private String name;
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getConfirmPassword() {
			return confirmPassword;
		}
		public void setConfirmPassword(String confirmPassword) {
			this.confirmPassword = confirmPassword;
		}
		public String getRole() {
			return role;
		}
		public void setRole(String role) {
			this.role = role;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public manageUserBean(String username, String password, String confirmPassword, String role, String status,
				String name) {
			super();
			this.username = username;
			this.password = password;
			this.confirmPassword = confirmPassword;
			this.role = role;
			this.status = status;
			this.name = name;
		}
		@Override
		public String toString() {
			return "manageUser [username=" + username + ", password=" + password + ", confirmPassword=" + confirmPassword
					+ ", role=" + role + ", status=" + status + ", name=" + name + "]";
		}
	}


 