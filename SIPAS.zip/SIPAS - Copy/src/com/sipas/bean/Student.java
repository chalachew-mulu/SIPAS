package com.sipas.bean;

public class Student {
String studID;
String fname;
String lname;
String gname;
String mother;
String mobile;
String email;
String year;
String department;
String faculty;
String username;
String password;
public Student() {
	super();
}
public String getStudID() {
	return studID;
}
public void setStudID(String studID) {
	this.studID = studID;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}
public String getGname() {
	return gname;
}
public void setGname(String gname) {
	this.gname = gname;
}
public String getMother() {
	return mother;
}
public void setMother(String mother) {
	this.mother = mother;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getFaculty() {
	return faculty;
}
public void setFaculty(String faculty) {
	this.faculty = faculty;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

}
