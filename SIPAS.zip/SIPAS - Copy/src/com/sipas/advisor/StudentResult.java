package com.sipas.advisor;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;
  
@WebServlet("/studentResult")
public class StudentResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement stm,stm1;
	HttpSession session;
	ResultSet rs;
	int status = 0;
    public StudentResult() {
        super();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException{
     session = request.getSession();
     String page = "";
    
     if(request.getParameter("result")!=null){
    	String stud_name = request.getParameter("stud_name");
      	float score = Float.parseFloat(request.getParameter("score"));
      	String super_name = request.getParameter("super_name");
	    java.sql.Date date_submited = new java.sql.Date(new java.util.Date().getTime());
    	con = DBConnection.getMysqlConnection();
    	try {
    		Statement stm1 = (Statement) con.createStatement();
    		rs = (ResultSet) stm1.executeQuery("select count(result_submit_by_adv_id) from student_result where student_id='"+stud_name+"'");
 	        int count = 0;
 	        while (rs.next()) {
			 count = count+rs.getInt(1);	
			}
 	        if (count > 0) {
 	 	        System.out.println(count);
				request.setAttribute("message", "Student Result Was Allready Submitted Before!!");
				page = "Advisor/student_result.jsp";
	    		response.setHeader("refresh", "3;Advisor/student_result.jsp");
	        }else{
             double supervisor_score= 0.0;
	        Statement super_stm = (Statement) con.createStatement();
    		ResultSet super_res = (ResultSet) super_stm.executeQuery("select score from student_result r, supervisor s,student std where r.student_id=std.studID and r.result_submit_by_super_id=s.super_id and r.student_id='"+stud_name+"'");
            
    		if (super_res.next()) {	
            	supervisor_score = super_res.getFloat("r.score");
                double x = supervisor_score+score;
                String grade = "";
                if (x>=90) {
                	grade = "A+";
					System.out.println("A+");
				}else if (x>=85 && x<90) {
                	grade = "A";
					System.out.println("A");
				}else if (x>=80 && x<85) {
                	grade = "A-";
					System.out.println("A-");
				}else if (x>=75 && x<80) {
                	grade = "B+";
					System.out.println("B+");
				}else if (x>=70 && x<75) {
                	grade = "B";
					System.out.println("B");
				}else if (x>=65 && x<70) {
                	grade = "B-";
					System.out.println("B-");
				}else if (x>=60 && x<65) {
                	grade = "C+";
					System.out.println("C+");
				}else if (x>=50 && x<60) {
                	grade = "C";
					System.out.println("C");
				}else if (x>=45 && x<50) {
                	grade = "C-";
					System.out.println("C-");
				}else if (x>=40 && x<45) {
                	grade = "D";
					System.out.println("D");
				}else if (x>=35 && x<40) {
                	grade = "Fx";
					System.out.println("Fx");
				}else{
                	grade = "F";
					System.out.println("F");
				}       
                System.out.println("Grade is" +grade);
    			stm = (Statement) con.createStatement();
    			String query = "insert into student_result(student_id,score,result_submit_date,result_submit_by_adv_id) values('"+stud_name+"','"+score+"','"+date_submited+"','"+super_name+"')";
    			status = stm.executeUpdate(query);
    			if (status > 0) {
    	   			String adgrade = "insert into student_grade(number_grade,letter_grade,student_id,submit_by_id,date_submitted) "
    	   					+ "values('"+x+"','"+grade+"','"+stud_name+"','"+super_name+"','"+date_submited+"')"; 
        			stm.executeUpdate(adgrade);
        			stm.executeUpdate("update student set status='Deactive' where studID = '"+stud_name+"'");
    				request.setAttribute("message", "Student Result Submited Success !!");
    				page = "Advisor/student_result.jsp";
    				response.setHeader("refresh", "3;Advisor/student_result.jsp");
    			}
    			else{
    				request.setAttribute("message", "Failed to Submit Student Result !!");
    				response.setHeader("refresh", "3;Advisor/student_result.jsp");
    				page = "Advisor/student_result.jsp";
    			}
            }else{
            	request.setAttribute("message", "Wait until Supervisor Submit Student Result ... !!");
				page = "Advisor/student_result.jsp";
				response.setHeader("refresh", "3;Advisor/student_result.jsp");
            }
		 }
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	request.getRequestDispatcher(page).forward(request, response);		
    }
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	processRequest(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	processRequest(request, response);
	}
}
