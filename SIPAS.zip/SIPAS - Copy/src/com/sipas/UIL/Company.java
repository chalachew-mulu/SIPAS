package com.sipas.UIL;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.mysql.jdbc.ResultSet;
import com.sipas.connection.DBConnection;

@WebServlet("/company")
@MultipartConfig(maxFileSize = 16177216)
public class Company extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    PreparedStatement stm;
    ResultSet result;
    public Company() {
        super();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response) 
    		throws ServletException, IOException {
   	 try {
   		 write = response.getWriter();
   		 session = request.getSession();
   		 String page = "";
   		 if (request.getParameter("register")!=null) {
            
   			 System.out.println("New Company");
   			 String name = request.getParameter("name");
   			 String email = request.getParameter("email");
   			 String capacity = request.getParameter("capacity");
   			 String website = request.getParameter("website");
   			 String fax = request.getParameter("fax");
   			 String region = request.getParameter("region");
   			 String city = request.getParameter("city");
   			 String kebele = request.getParameter("kebele");
   			 String zone = request.getParameter("zone");
   			 String description = request.getParameter("description");
   			 Part part = request.getPart("logo");
   			 String fileName = extractFileName(part);
   			 int reserved = 0;
             String path = "D:\\Courses\\5 Fifth Year\\Second Semister\\SIPAS\\WebContent\\uploads" + File.separator + fileName;
             //System.out.println("image PAth"+path);
             //System.out.println("Project PAth = "+request.getServletContext().getRealPath(""));
             //File fileSaveDir = new File(path);
             part.write(path);
             
   	            con = DBConnection.getMysqlConnection();
       			 String query = "insert into company(companyName,website,region,city,email,fax,zone,kebele,capacity,description,photo,reserved)"
       			 		+ " values(?,?,?,?,?,?,?,?,?,?,?,?)";
       			 stm = con.prepareStatement(query);
       			 stm.setString(1, name);
       			 stm.setString(2, website);
       			 stm.setString(3, region);
       			 stm.setString(4, city);
       			 stm.setString(5, email);
       			 stm.setString(6, fax);
       			 stm.setString(7, zone);
       		     stm.setString(8, kebele);
       		     stm.setString(9, capacity);
       		     stm.setString(10, description);
       		     stm.setString(11, fileName);
        		 stm.setInt(12, reserved);

       		     status = stm.executeUpdate();
       			 if (status > 0) {
       				session.setAttribute("name", name);
       				request.setAttribute("message", "New Company Added !!");
       				page = "UIL/company.jsp";
                    //request.getRequestDispatcher("UIL/company.jsp").forward(request, response);
    				response.setHeader("refresh", "2;UIL/company.jsp");
       			}
       			 
       			 else{
       				write.println("oops! Something Went Wrong...");
       				response.setHeader("refresh", "2;UIL/company.jsp");
       			 }
       			 request.getRequestDispatcher(page).forward(request, response);
   		 }
   	} catch(SQLException e) {
   		e.printStackTrace();
   	}
    }
   	@Override
   	protected void doGet(HttpServletRequest request, HttpServletResponse response)
   	throws ServletException, IOException{
   		processRequest(request, response);
   	}
   	@Override
   	protected void doPost(HttpServletRequest request, HttpServletResponse response)
   	throws ServletException, IOException{
   		processRequest(request, response);
   	}
	public String extractFileName(Part part){
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String string : items) {
			if (string.trim().startsWith("filename")) {
             		return string.substring(string.indexOf("=") + 2, string.length() - 1);		
			}
		}
		return "";
	}
}
