package com.sipas.UIL;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/addfacultyDean")
public class FacultyDean extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public FacultyDean() {
        super();
     }    
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
		 write = response.getWriter();
		 session = request.getSession();
        try {
            if(request.getParameter("register")!=null ) {
            	String fid = request.getParameter("fid");
        		String fname = request.getParameter("fname");
        		String lname = request.getParameter("lname");
        		String mobile = request.getParameter("mobile");
        		String faculty = request.getParameter("faculty");
        		String email = request.getParameter("email");
        		String office = request.getParameter("office");
     
   			 con = DBConnection.getMysqlConnection();
   			 stm = (Statement) con.createStatement();
   			 String query = "insert into faculty_dean(facultyDeanID, firstname,lastname,email,mobile,officeNumber,faculty)"
   			 		        + " values('"+fid+"','"+fname+"','"+lname+"','"+email+"','"+mobile+"','"+office+"','"+faculty+"')";
   			 status = stm.executeUpdate(query);
   			 if (status > 0) {
   				session.setAttribute("fname", fname);
   				request.setAttribute("message", "Faculty Dean Added !!");
                request.getRequestDispatcher("UIL/faculty_dean.jsp").forward(request, response);
                response.setHeader("refresh", "2;UIL/faculty_dean.jsp");
   			 }
   			 else{
    		     request.setAttribute("message", "Failed to Add Dean Added !!");
                 write.println("no");
                 response.setHeader("refresh", "2;UIL/faculty_dean.jsp");
   			 } 
   		}          
	      } catch (Exception e) {
          e.printStackTrace();
		}
	}

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
    
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{                            
		processRequest(request, response);
	}
}
