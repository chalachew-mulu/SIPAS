package com.sipas.UIL;
public class UploadPicture {

}