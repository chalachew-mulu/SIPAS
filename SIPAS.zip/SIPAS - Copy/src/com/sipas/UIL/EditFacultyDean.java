package com.sipas.UIL;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/editFacultyDean")
public class EditFacultyDean extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public EditFacultyDean() {
        super();
     }    
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
		 write = response.getWriter();
		 session = request.getSession();
		 String page = "";
        try {	 
        	if (request.getParameter("updateDean") != null) { 
   			int id = Integer.parseInt(request.getParameter("id")); 
         	String fid = request.getParameter("fid");
     		String fname = request.getParameter("fname");
     		String lname = request.getParameter("lname");
     		String mobile = request.getParameter("mobile");
     		String faculty = request.getParameter("faculty");
     		String email = request.getParameter("email");
     		String office = request.getParameter("office");

   			 con = DBConnection.getMysqlConnection();
   			 stm = (Statement) con.createStatement();
   			 String updateQuery = "update faculty_dean set facultyDeanID='"+fid+"',firstname='"+fname+"',lastname='"+lname+"',email='"+email+"',mobile='"+mobile+"',officeNumber='"+office+"',faculty='"+faculty+"' where id = '"+id+"'";
   			 
   			 status = stm.executeUpdate(updateQuery);
   			 if (status > 0) {
   			    request.setAttribute("message", "Faculty Dean Information Updated Successfully");
   			    page = "UIL/editFaculty_dean.jsp";
   				response.setHeader("refresh", "2;UIL/faculty_dean.jsp");
	    	 }else{
   			 write.println("oops! Something Went Wrong ...");	
   			}
   			request.getRequestDispatcher(page).forward(request, response);
   		}
          
	      } catch (Exception e) {
          e.printStackTrace();
		}
	}

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
    
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
}
