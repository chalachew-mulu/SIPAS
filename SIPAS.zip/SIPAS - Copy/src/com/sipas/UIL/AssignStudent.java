package com.sipas.UIL;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/assignStudent")
public class AssignStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	ResultSet rs;
	Statement stm,stm2,stm3;
	int status = 0;  
    public AssignStudent() {
        super();
       }  
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException,IOException{
    String page = "";	
    try{	
    if (request.getParameter("assign")!=null) {
		String company = request.getParameter("company");
		String [] student = request.getParameterValues("student");
		
	    String start = request.getParameter("start");
	    String end = request.getParameter("end");
	    String duration = request.getParameter("duration");
	   
	    java.text.DateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy");
	   
	    java.util.Date startDate = format.parse(start);
	    java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());

	    java.util.Date endDate = format.parse(end);
	    java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
	    
	    java.sql.Date date_assigned = new java.sql.Date(new java.util.Date().getTime());
	 
		 con = (Connection) DBConnection.getMysqlConnection();
		 stm = (Statement) con.createStatement();
		 for(String i : student){
		    String query = "insert into internship_request(student_id, comp_id, ac_status, start_date, end_date, duration,date_responsed) values('"+i+"','"+company+"','1','"+sqlStartDate+"','"+sqlEndDate+"','"+duration+"','"+date_assigned+"')";
			status = stm.executeUpdate(query); 
			if (status > 0) {
		    	  String query1 = "delete from internship_request where student_id='"+i+"' and ac_status = '2' or ac_status='3'";
		    	  stm.executeUpdate(query1);
				  request.setAttribute("message", "Student Assigned Success !!");	
				  page = "UIL/assign_student.jsp";
				  response.setHeader("refresh", "2;UIL/assign_student.jsp");
			}else{
				
				  request.setAttribute("message", "Student Assignation Failed !!");	
				  page = "UIL/assign_student.jsp";
				  response.setHeader("refresh", "2;UIL/assign_student.jsp");
			}
		 }
		request.getRequestDispatcher(page).forward(request, response); 
	}
    }catch (Exception e) {
      e.printStackTrace();
    }	
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
    		throws ServletException, IOException {
	processRequest(request, response);
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	processRequest(request, response);
	}

}
