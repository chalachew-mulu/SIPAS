package com.sipas.supervisor;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/attendance")
public class Attendance extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement stm;
	ResultSet rs,rs2;
	HttpSession sesssion;
	int status = 0;
	String page;
    public Attendance() {
        super();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException{
     sesssion = request.getSession();
     if (request.getParameter("present")!=null) {
	   String student_id = request.getParameter("stud_id");	
	   String atten_status = "Present";
	   Date today_date = new java.sql.Date(new java.util.Date().getTime());
	   con = DBConnection.getMysqlConnection();
	   try {
	    stm = (Statement) con.createStatement();   
		String query =  "insert into student_attendance(student_id,status,date) values('"+student_id+"','"+atten_status+"','"+today_date+"')";  
		status = stm.executeUpdate(query);
		if (status > 0) {
			request.setAttribute("message", "Student checked present !");
			page = "Supervisor/attendance.jsp";
			response.setHeader("refresh", "1;Supervisor/attendance.jsp");
		}
		request.getRequestDispatcher(page).forward(request, response);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	   
	}
     else if (request.getParameter("abcent")!=null) {
	   String student_id = request.getParameter("stud_id");	
	   String atten_status = "Abcent";
	   Date today_date = new java.sql.Date(new java.util.Date().getTime());
	   con = DBConnection.getMysqlConnection();
	   try {
	    stm = (Statement) con.createStatement();   
		String query =  "insert into student_attendance(student_id,status,date) values('"+student_id+"','"+atten_status+"','"+today_date+"')";  
		status = stm.executeUpdate(query);
		if (status > 0) {
			request.setAttribute("message", "Student checked abcent !");
			page = "Supervisor/attendance.jsp";
			response.setHeader("refresh", "1;Supervisor/attendance.jsp");
		}
		request.getRequestDispatcher(page).forward(request, response);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	   
	}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		processRequest(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}
}
