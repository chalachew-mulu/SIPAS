package com.sipas.supervisor;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/submitResult")
public class SubmitResult extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement stm,stm1;
	HttpSession session;
	ResultSet rs;
	int status = 0;
    public SubmitResult() {
        super();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException{
     session = request.getSession();
     String page = "";
    
     if(request.getParameter("result")!=null){
    	String stud_name = request.getParameter("stud_name");
      	float score = Float.parseFloat(request.getParameter("score"));
      	float stud_score = (float) (score*0.3);
      	String super_name = request.getParameter("super_name");
	    java.sql.Date date_submited = new java.sql.Date(new java.util.Date().getTime());
    	con = DBConnection.getMysqlConnection();
    	try {
    		Statement stm1 = (Statement) con.createStatement();
    		rs = (ResultSet) stm1.executeQuery("select count(result_submit_by_super_id) from student_result where student_id='"+stud_name+"'");
 	        int count = 0;
 	        while (rs.next()) {
			 count = count+rs.getInt(1);	
			}
 	        if (count > 0) {
				request.setAttribute("message", "Student Result Was Allready Submitted Before!!");
				page = "Supervisor/student_result.jsp";
	    		response.setHeader("refresh", "3;Supervisor/student_result.jsp");
	        }else{
			stm = (Statement) con.createStatement();
			String query = "insert into student_result(student_id,score,result_submit_date,result_submit_by_super_id) values('"+stud_name+"','"+stud_score+"','"+date_submited+"','"+super_name+"')";
			status = stm.executeUpdate(query);
			if (status > 0) {
				request.setAttribute("message", "Student Result Submited Success !!");
				page = "Supervisor/student_result.jsp";
				response.setHeader("refresh", "3;Supervisor/student_result.jsp");
			}
			else{
				request.setAttribute("message", "Failed to Submit Student Result !!");
				response.setHeader("refresh", "3;Supervisor/student_result.jsp");
				page = "Supervisor/student_result.jsp";
			}
		 }
		} catch (SQLException e) {
			e.printStackTrace();
		}
    	request.getRequestDispatcher(page).forward(request, response);		
    }
     else if(request.getParameter("update")!=null){
		  
	  }
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	processRequest(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	processRequest(request, response);
	}

}
