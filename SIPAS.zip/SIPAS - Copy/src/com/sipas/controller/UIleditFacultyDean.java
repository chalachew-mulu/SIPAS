package com.sipas.controller;

import java.util.List;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sipas.dao.UILmanageFacultyDeanDao;
import com.sipas.bean.UILmanageFacultyDeanBean;;

@WebServlet("/edit")
public class UIleditFacultyDean extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UIleditFacultyDean() {
        super();
        }
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 int ids = Integer.parseInt(request.getParameter("id"));
 int id = ids;
 UILmanageFacultyDeanDao im = new UILmanageFacultyDeanDao();
 UILmanageFacultyDeanBean faculty = im.getFacultyDeanID(id);
 List <UILmanageFacultyDeanBean> faculties = im.listFacultyDean();
 
 request.setAttribute("faculty", faculty);
 request.setAttribute("faculties", faculties);
 
 RequestDispatcher rd = request.getRequestDispatcher("UIL/edit_faculty_dean.jsp");
 rd.forward(request, response);
}
}
