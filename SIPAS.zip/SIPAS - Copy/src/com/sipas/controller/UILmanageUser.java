package com.sipas.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sipas.dao.UILmanageUserDao;
import com.sipas.bean.UILmanageUserBean;

@WebServlet("/addUser")
public class UILmanageUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UILmanageUser() {
        super();
     }    
  public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
        UILmanageUserDao userDao = new UILmanageUserDao();     
        String action = request.getParameter("view");
        if(action != null) {
        	String role = request.getParameter("role");
    		String username = request.getParameter("deanUsername");
    		String password = request.getParameter("deanPassword");
    		String status = request.getParameter("deanStatus");
    		String name = request.getParameter("deanName");
    		
			UILmanageUserBean facultyDean = new UILmanageUserBean(role, username, password, status, name);
				    boolean addFacultyDean = userDao.addUser(facultyDean);
				if (addFacultyDean) {
					request.setAttribute("success", "New faculty dean added");
				} else {
					request.setAttribute("error", "Failed to add faculty dean");
				}
        }        
		List<UILmanageUserBean> users = userDao.listUser();
		request.setAttribute("users", users);		
        RequestDispatcher rd = request.getRequestDispatcher("UIL/manage_user.jsp");
        rd.forward(request, response);
	}
}
