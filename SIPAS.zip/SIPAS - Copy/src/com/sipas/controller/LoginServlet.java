package com.sipas.controller;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;
import com.sipas.system.PasswordEncryption;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
Connection con;
Statement stm;
ResultSet rs;
public LoginServlet() {
}
protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
{
	 String userNameDB = "";
	 String passwordDB = "";
	 String roleDB = "";
	 String statusDB = "";
	 String page="";
	 PasswordEncryption pe = new PasswordEncryption();
	 HttpSession session = request.getSession(true);
try{
if(request.getParameter("login")!=null){
	 String userName = request.getParameter("username");
	 String password = request.getParameter("password");

	 con = DBConnection.getMysqlConnection();
	 stm = (Statement) con.createStatement();
	 rs = (ResultSet) stm.executeQuery("select * from sipas_user where username='"+userName+"' and password='"+pe.Encrypt(password)+"'");
	 if(rs.next())
	 {
	 session.setAttribute("loggedin", "yes");	 
	 userNameDB = rs.getString("username");
	 passwordDB = rs.getString("password");
	 roleDB = rs.getString("role");
	 statusDB = rs.getString("status");
	 
	 if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("admin"))
	 {
	 System.out.println("Admin's Home"); //Creating a session
	 session.setAttribute("Admin", userName); //setting session attribute
	 request.setAttribute("userName", userName);
	 session.setAttribute("role", roleDB); //setting session attribute
	 page="UIL/UIL.jsp";
	 }
	 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Faculty") && statusDB.equals("Active"))
	 {
	 String faculty = "";	
	 int id=0;
	 con = DBConnection.getMysqlConnection();
	 stm = (Statement) con.createStatement();
	 rs = (ResultSet) stm.executeQuery("select faculty,d.id from faculty_dean d, sipas_user u where u.dean_id = d.id and username='"+userName+"'");
	 if (rs.next()) {
	  faculty = rs.getString("faculty");
	  id = rs.getInt("d.id");
	 }
	 session.setAttribute("Faculty", userName);
	 session.setAttribute("faculty", faculty);
	 session.setAttribute("facultyID", id);
	 session.setAttribute("role", roleDB); //setting session attribute
	 request.setAttribute("userName", userName);
	 page="/Faculty/faculty.jsp";
	 }
	 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Advisor") && statusDB.equals("Active")){
		 String faculty = "";
		 String advisor = "";
		 con = DBConnection.getMysqlConnection();
		 stm = (Statement) con.createStatement();
		 rs = (ResultSet) stm.executeQuery("select d.advisor_id,d.faculty from advisor d, sipas_user u where u.advisor_id = d.id and username='"+userName+"'");
		 if (rs.next()) {
		  faculty = rs.getString("d.faculty");
		  advisor = rs.getString("d.advisor_id");
		 }	 
		 session.setAttribute("Advisor", userName);
		 session.setAttribute("faculty", faculty);
		 session.setAttribute("advisor", advisor);
		 request.setAttribute("userName", userName); 
		 page="/Advisor/advisor.jsp";
	 }
	 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Coordinator") && statusDB.equals("Active")){
		 String companyName = "";	
		 int comp_id = 0;
		 int cordID = 0;
		 con = DBConnection.getMysqlConnection();
		 stm = (Statement) con.createStatement();
		 rs = (ResultSet) stm.executeQuery("SELECT comp.companyName,cord.id,comp.id FROM coordinator cord, company comp,sipas_user user WHERE cord.company_id = comp.id and user.cord_id = cord.id and user.username ='"+userName+"'");
		 if (rs.next()) {
		  companyName = rs.getString("companyName");
		  comp_id = rs.getInt("comp.id");
		  cordID = rs.getInt("cord.id");
		 }	 
		 session.setAttribute("Coordinator", userName);
		 session.setAttribute("role", roleDB); //setting session attribute
		 session.setAttribute("companyName", companyName);
		 session.setAttribute("companyID", comp_id);
		 session.setAttribute("cordID", cordID);
		 request.setAttribute("userName", userName); 
		 page="/Coordinator/coordinator.jsp"; 
	 }
	 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Supervisor") && statusDB.equals("Active")){
		 String company = "";	
		 String supervisor = "";
		 con = DBConnection.getMysqlConnection();
		 stm = (Statement) con.createStatement();
		 rs = (ResultSet) stm.executeQuery("select * from supervisor d,company c,sipas_user u where u.super_id = d.id and d.comp_id=c.id and username='"+userName+"'");
		 if (rs.next()) {
		  company = rs.getString("c.id");
		  supervisor = rs.getString("d.super_id");
		 }	 	 
		 session.setAttribute("Supervisor", userName);
		 session.setAttribute("supervisor", supervisor);
		 session.setAttribute("company", company);
		 request.setAttribute("userName", userName); 
		 page="/Supervisor/supervisor.jsp";
	 }else{
		request.setAttribute("errMessage", "Invalid Username or Password");
		page="login.jsp";
	 }
	 }else{
		 request.setAttribute("errMessage", "Invalid Username or Password");
		 page = "login.jsp";
	 }
	 request.getRequestDispatcher(page).forward(request, response);
}
}catch(Exception e){
	e.printStackTrace();
}
}
 /*String userName = request.getParameter("username");
 String password = request.getParameter("password");
 
 LoginBean loginBean = new LoginBean();
 
 loginBean.setUserName(userName);
 loginBean.setPassword(password);
 LoginDao loginDao = new LoginDao();
 try
 {
 String userValidate = loginDao.authenticateUser(loginBean);
 
 if(userValidate.equals("Admin_Role"))
 {
 System.out.println("Admin's Home");
 HttpSession session = request.getSession(); //Creating a session
 session.setAttribute("Admin", userName); //setting session attribute
 request.setAttribute("userName", userName);
 request.getRequestDispatcher("UIL/UIL.jsp").forward(request, response);
 }
 else if(userValidate.equals("Faculty_Role"))
 {
 String faculty = "";	 
 con = DBConnection.getMysqlConnection();
 stm = (Statement) con.createStatement();
 rs = (ResultSet) stm.executeQuery("select faculty from faculty_dean d, sipas_user u where u.dean_id = d.id and username='"+userName+"'");
 if (rs.next()) {
  faculty = rs.getString("faculty");	
 }
 HttpSession session = request.getSession();
 session.setAttribute("Faculty", userName);
 session.setAttribute("faculty", faculty);
 request.setAttribute("userName", userName);
 request.getRequestDispatcher("/Faculty/faculty.jsp").forward(request, response);
 }
 else if(userValidate.equals("Student_Role"))
 {
 HttpSession session = request.getSession();
 session.setAttribute("Student", userName);
 request.setAttribute("userName", userName); 
 request.getRequestDispatcher("/Student/student.jsp").forward(request, response);
 }
 else if(userValidate.equals("Advisor_Role"))
 {
 String faculty = "";
 String advisor = "";
 con = DBConnection.getMysqlConnection();
 stm = (Statement) con.createStatement();
 rs = (ResultSet) stm.executeQuery("select d.advisor_id,d.faculty from advisor d, sipas_user u where u.advisor_id = d.id and username='"+userName+"'");
 if (rs.next()) {
  faculty = rs.getString("d.faculty");
  advisor = rs.getString("d.advisor_id");
 }	 
 HttpSession session = request.getSession();
 session.setAttribute("Advisor", userName);
 session.setAttribute("faculty", faculty);
 session.setAttribute("advisor", advisor);
 request.setAttribute("userName", userName); 
 request.getRequestDispatcher("/Advisor/advisor.jsp").forward(request, response);
 }
 else if(userValidate.equals("Coordinator_Role"))
 {
 String companyName = "";	
 int comp_id = 0;
 con = DBConnection.getMysqlConnection();
 stm = (Statement) con.createStatement();
 rs = (ResultSet) stm.executeQuery("SELECT comp.companyName,comp.id FROM coordinator cord, company comp,sipas_user user WHERE cord.company_id = comp.id and user.cord_id = cord.id and user.username ='"+userName+"'");
 if (rs.next()) {
  companyName = rs.getString("companyName");
  comp_id = rs.getInt("comp.id");
 }	 
 HttpSession session = request.getSession();
 session.setAttribute("Coordinator", userName);
 
 session.setAttribute("companyName", companyName);
 session.setAttribute("companyID", comp_id);
 
 request.setAttribute("userName", userName); 
 request.getRequestDispatcher("/Coordinator/coordinator.jsp").forward(request, response);
 }
 else if(userValidate.equals("Supervisor_Role"))
 {
 String company = "";	
 String supervisor = "";
 con = DBConnection.getMysqlConnection();
 stm = (Statement) con.createStatement();
 rs = (ResultSet) stm.executeQuery("select * from supervisor d,company c,sipas_user u where u.super_id = d.id and d.comp_id=c.id and username='"+userName+"'");
 if (rs.next()) {
  company = rs.getString("c.id");
  supervisor = rs.getString("d.super_id");
 }	 	 
 HttpSession session = request.getSession();
 session.setAttribute("Supervisor", userName);
 session.setAttribute("supervisor", supervisor);
 session.setAttribute("company", company);
 request.setAttribute("userName", userName); 
 request.getRequestDispatcher("/Supervisor/supervisor.jsp").forward(request, response);
 }
 else
 {
 System.out.println("Error message = "+userValidate);
 request.setAttribute("errMessage", userValidate);
 request.getRequestDispatcher("login.jsp").forward(request, response);
 }
 }
 catch (IOException e1)
 {
 e1.printStackTrace();
 }
 catch (Exception e2)
 {
 e2.printStackTrace();
 }
} //End of doPost()*/
public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException{
	 processRequest(request, response);
	}
public void doPost(HttpServletRequest request, HttpServletResponse response) 
		throws ServletException, IOException{
	 processRequest(request, response);
		}
}