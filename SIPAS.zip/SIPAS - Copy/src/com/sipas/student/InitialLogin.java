package com.sipas.student;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;
import com.sipas.system.PasswordEncryption;
 
@WebServlet("/pass")
public class InitialLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
    HttpSession session;
    Connection con;
    Statement stm;
    ResultSet rs;
    
 public InitialLogin() {
        super();
     }
  protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException{
	      String page = "";
          session = request.getSession();
	  try {
    	if (request.getParameter("logon")!=null) {
    		
    	String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		con = DBConnection.getMysqlConnection();
		stm = (Statement) con.createStatement();
		rs = (ResultSet) stm.executeQuery("select * from student where username ='"+username+"'");
		while (rs.next()) {
			PasswordEncryption pe = new PasswordEncryption();
			String pwd = pe.Encrypt(password);
			String userDB = rs.getString("username");
			String pwdDB = rs.getString("password");
			String statusDb = rs.getString("status");
			if (username.equals(userDB) && pwd.equals(pwdDB) && statusDb.equals("Active")) {
				session.setAttribute("username", username);
				page = "Student/student.jsp";			
			}
			/*else{
				page = "apply.jsp";
				session.setAttribute("message", "Invalid Username or Password");	
			}*/
		}
	    request.getRequestDispatcher(page).forward(request, response);
		} 
    	}catch (SQLException | NoSuchAlgorithmException e) {
			e.printStackTrace();
	}	
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
   		processRequest(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
   		processRequest(request, response);
	}

}
