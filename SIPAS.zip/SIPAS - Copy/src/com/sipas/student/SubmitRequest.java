package com.sipas.student;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/submitRequest")
public class SubmitRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement stm;
	
	ResultSet rs,rs2,rs3;
	int addStatus = 0;
	HttpSession session;
	PrintWriter pw;
    public SubmitRequest() {
        super();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    		throws SecurityException, IOException{
    	session = request.getSession();
    	pw = response.getWriter();
    	String page = "";
    	try{		
     if(request.getParameter("request")!=null) {
 	        con = (Connection) DBConnection.getMysqlConnection();	 
 	        String start = request.getParameter("start");
    	    String end = request.getParameter("end");
    	    String studID = request.getParameter("studID");
    	    int comp_id = Integer.parseInt(request.getParameter("comp_id"));
    	    String description = request.getParameter("description");
    	    java.text.DateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy");
    	    
    	    java.util.Date startDate = format.parse(start);
    	    java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());

    	    java.util.Date endDate = format.parse(end);
    	    java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
    	    
    	    java.sql.Timestamp Date_requested = new java.sql.Timestamp(new java.util.Date().getTime());
    	    
    	    //String Date_responded = new java.sql.Timestamp(new java.util.Date().getTime()).toString();
 	    
 	        Statement stm1 = (Statement) con.createStatement();
 	        rs = (ResultSet) stm1.executeQuery("select count(*) from internship_request where student_id='"+studID+"'");
 	        //rs = (ResultSet) stm1.executeQuery("select count(comp_id) from internship_request where student_id='"+studID+"' and comp_id='"+comp_id+"'");
 	        int count=0;
 	        while(rs.next()) {
 	        	count = count+rs.getInt(1);
 	         }
 	        System.out.println(count);
 	        if (count < 5) {
 	        	rs2 = (ResultSet) stm1.executeQuery("select count(comp_id) from internship_request where comp_id='"+comp_id+"' and student_id='"+studID+"'");
 	        	int count2 = 0;
 	        while (rs2.next()) {
				  count2 = count2+rs2.getInt(1);	
				}
 	        if(count2 < 1){	
				String query = "insert into internship_request(student_id, comp_id, ac_status, start_date, end_date, duration,date_requested,description,date_responsed) values(?,?,?,?,?,?,?,?,?)";
				stm = (PreparedStatement) con.prepareStatement(query);
				stm.setString(1, request.getParameter("studID"));
				stm.setString(2, request.getParameter("comp_id"));
				stm.setInt(3, 2);
				stm.setDate(4, sqlStartDate);
				stm.setDate(5, sqlEndDate);
				stm.setString(6, request.getParameter("duration"));
				stm.setTimestamp(7, Date_requested);
				stm.setString(8, description);
				stm.setString(9, "Request Not Seen");
				
				addStatus = stm.executeUpdate();
				if (addStatus > 0) {
				   request.setAttribute("message", "Your Request Submitted Successfully !!");
				   //request.getRequestDispatcher("Student/applyInternship.jsp").forward(request, response);
				   page = "Student/applyInternship.jsp";
				   response.setHeader("refresh", "3;Student/internship_company.jsp");
				}
				else{
				   request.setAttribute("message", "Your Request Failed !!");
				   //request.getRequestDispatcher("Student/applyInternship.jsp").forward(request, response);
				   page = "Student/applyInternship.jsp";
			   }
 	         }else{
 				request.setAttribute("message", "You already requested this company !!");
 				//request.getRequestDispatcher("Student/applyInternship.jsp").forward(request, response);
 				page = "Student/applyInternship.jsp";
 				response.setHeader("refresh", "3;Student/internship_company.jsp");
 	         }
			 }
			else{
				request.setAttribute("message", "Maximum Request Limit !!");
				//request.getRequestDispatcher("Student/applyInternship.jsp").forward(request, response);
				page = "Student/applyInternship.jsp";
 				response.setHeader("refresh", "3;Student/internship_company.jsp");
			}
	    	request.getRequestDispatcher(page).forward(request, response); 
    	  }
		}catch (Exception e) {
			e.printStackTrace();
		}
      }
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	    processRequest(request, response);
	}
}
