package com.sipas.faculty_dean;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import javax.servlet.annotation.MultipartConfig;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;
@MultipartConfig
@WebServlet("/uploadStudentFile")
public class UploadStudentFile extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public UploadStudentFile() {
        super();
    }
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String page = "";
      	try {  
	      		
	      	    Part file = request.getPart("student");
	      	    String filename = getFilename(file);
	      	    InputStream filecontent = file.getInputStream();
	      	    System.out.println(filename);
	      	    
      		   //FileInputStream input = new FileInputStream("D:\\Courses\\5 Fifth Year\\Second Semister\\SIPAS\\student.xls");
        	   POIFSFileSystem fs = new POIFSFileSystem(filecontent);
        	   Workbook wb; 
        	   wb = WorkbookFactory.create(fs);
        	   Sheet sheet = wb.getSheetAt(0);
        	   Row row;
        	   for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                   row = (Row)sheet.getRow(i);
                   String studID = row.getCell(0).getStringCellValue();
                   String fname = row.getCell(1).getStringCellValue();
                   String lname = row.getCell(2).getStringCellValue();
                   String gname = row.getCell(3).getStringCellValue();
                   String mother = row.getCell(4).getStringCellValue();
                   String mobile = row.getCell(5).getStringCellValue();
                   String email = row.getCell(6).getStringCellValue();
                   int year = (int) row.getCell(7).getNumericCellValue(); 
                   String department = row.getCell(8).getStringCellValue();
                   String faculty = row.getCell(9).getStringCellValue();
                   con = DBConnection.getMysqlConnection();
            	   stm = (Statement) con.createStatement();
                   String sql = "insert into student(studID,firstname,lastname,grandfather,mothername,mobile,email,department,faculty,year)"
       	   		        + "values('"+studID+"','"+fname+"','"+lname+"','"+gname+"','"+mother+"','"+mobile+"','"+email+"','"+department+"','"+faculty+"','"+year+"')";
                   stm = (Statement) con.prepareStatement(sql);
                   status = stm.executeUpdate(sql);
                   if (status > 0) {
                	  request.setAttribute("message", "Student File Imported Successfully !!");
                	  page = "Faculty/uploadfromexcel.jsp";
                	  response.setHeader("refresh", "3;Faculty/register_student.jsp");
				}
                   else{
                	  request.setAttribute("message", "Student File Imported Failed !!");
                 	  page = "Faculty/uploadfromexcel.jsp";
                 	  response.setHeader("refresh", "3;Faculty/register_student.jsp");
                   }
        	   }
        	   request.getRequestDispatcher(page).forward(request, response);
        	   /*
        	   FileInputStream input = new FileInputStream(request.getParameter("student"));
               POIFSFileSystem fs = new POIFSFileSystem(input);
               HSSFWorkbook wb = new HSSFWorkbook(fs);
               
               HSSFSheet sheet = wb.getSheetAt(0);
               Row row;
               for (int i = 1; i <= sheet.getLastRowNum(); i++) {

                   row = sheet.getRow(i);
                   String studID = row.getCell(0).getStringCellValue();
                   String fname = row.getCell(1).getStringCellValue();
                   String lname = row.getCell(2).getStringCellValue();
                   String gname = row.getCell(3).getStringCellValue();
                   String mother = row.getCell(4).getStringCellValue();
                   String mobile = row.getCell(5).getStringCellValue();
                   String email = row.getCell(6).getStringCellValue();
                   String department = row.getCell(7).getStringCellValue();
                   String faculty = row.getCell(8).getStringCellValue();
                   int year = (int) row.getCell(9).getNumericCellValue();
            	   
                   con = DBConnection.getMysqlConnection();
            	   stm = (Statement) con.createStatement();
                   String sql = "insert into student(studID,firstname,lastname,grandfather,mothername,mobile,email,department,faculty,year)"
       	   		        + "values('"+studID+"','"+fname+"','"+lname+"','"+gname+"','"+mother+"','"+mobile+"','"+email+"','"+department+"','"+faculty+"','"+year+"')";
                   stm = (Statement) con.prepareStatement(sql);
                   stm.executeUpdate(sql);
                   System.out.println("Success import excel to mysql table");
               }*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       processRequest(request, response);
	}
	  private static String getFilename(Part part) {
		    for (String cd : part.getHeader("content-disposition").split(";")) {
		      if (cd.trim().startsWith("filename")) {
		        String filename = cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
		        return filename.substring(filename.lastIndexOf('/') + 1).substring(filename.lastIndexOf('\\') + 1); // MSIE fix.
		      }
		    }
		    return null;
		  }
}
