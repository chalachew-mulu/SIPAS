package com.sipas.faculty_dean;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/registerAdvisor")
public class RegisterAdvisor extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public RegisterAdvisor() {
        super();
     }    
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
		 write = response.getWriter();
		 session = request.getSession();
		 String page = "";
        try {
            if(request.getParameter("register")!=null ) {
            	String advisorID = request.getParameter("advisorID");
        		String fname = request.getParameter("fname");
        		String lname = request.getParameter("lname");
        		String mobile = request.getParameter("mobile");
        		String faculty = request.getParameter("faculty");
        		String email = request.getParameter("email");
        		String office = request.getParameter("office");
        		String qualify = request.getParameter("qualify");
     
   			 con = DBConnection.getMysqlConnection();
   			 stm = (Statement) con.createStatement();
   			 String query = "insert into advisor(advisor_id, firstname,lastname,email,mobile,officeNumber,faculty,qualification)"
   			 		        + " values('"+advisorID+"','"+fname+"','"+lname+"','"+email+"','"+mobile+"','"+office+"','"+faculty+"','"+qualify+"')";
   			 status = stm.executeUpdate(query);
   			 if (status > 0) {
   				session.setAttribute("fname", fname);
   				request.setAttribute("message", "Advisor Added Successfuly!!");
   				response.setHeader("refresh", "3;Faculty/register_advisor.jsp");
   				page = "Faculty/register_advisor.jsp";
   			 }
   			 else{
    		    request.setAttribute("message", "Fail to add Advisor!!");
    	        page = "Faculty/register_advisor.jsp";
   			 } 
             request.getRequestDispatcher(page).forward(request, response); 
   		}
 
	      } catch (Exception e) {
          e.printStackTrace();
		}
	}
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
}
