package com.sipas.faculty_dean;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/assignAdvisor")
public class AssignAdvisor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	ResultSet rs;
	Statement stm,stm2,stm3;
	int status = 0;
	public AssignAdvisor() {
        super();
     }
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
			String page = "";		
		try{	
	if(request.getParameter("assign")!=null){
				 String [] student  = request.getParameterValues("student");
				 String advisor    =  request.getParameter("advisor"); 
			     java.sql.Timestamp date_assigned = new java.sql.Timestamp(new java.util.Date().getTime());
				 con = DBConnection.getMysqlConnection();
				 stm = (Statement) con.createStatement();
			
		    for (String i : student) { 			
				  String query = "insert into faculty_assign_advisor(advisor_id, student_id, date_assigned) values('"+advisor+"','"+i+"','"+date_assigned+"')";
				  status = stm.executeUpdate(query);
			//if (status > 0) {
				  //stm2 = (Statement) con.createStatement();
	   			  //String updateQuery = "update student set is_advisor_assigned='yes' where studID = '"+i+"'";
	   			 
	   			  //stm3 = (Statement) con.createStatement();
	   			  //String updateQuery2 = "update advisor set is_assigned_for_student='yes' where advisor_id = '"+advisor+"'";
	
	   			  //status = stm2.executeUpdate(updateQuery);
	   			  //status = stm2.executeUpdate(updateQuery2);

				if(status > 0){
					  stm.executeUpdate("insert into advisor_notify (advisor_id, assigned_student, date_assigned) values('"+advisor+"','"+i+"','"+date_assigned+"')");
				      request.setAttribute("message", "Advisor Assigned Success !!");	
					  page = "Faculty/assign_advisor.jsp";
					  response.setHeader("refresh", "2;Faculty/assign_advisor.jsp");
				  }else{
				      request.setAttribute("message", "Advisor Assigned Fail !!");	
					  page = "Faculty/assign_advisor.jsp";
					  response.setHeader("refresh", "2;Faculty/assign_advisor.jsp");
				  }
			     }
			  // } 
		       request.getRequestDispatcher(page).forward(request, response);
           }
         }catch (Exception e) {
    	 e.printStackTrace();
	 }
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
     processRequest(request, response);	
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
      processRequest(request, response);
	
	}
 }
