package com.sipas.faculty_dean;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/registerStudent")
public class RegisterStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public RegisterStudent() {
        super();
    }
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		session = request.getSession();
		try {
           if(request.getParameter("register")!=null){
        	   String studID = request.getParameter("studID");
        	   String fname = request.getParameter("fname");
        	   String lname = request.getParameter("lname");
        	   String gname = request.getParameter("gname");
        	   String mother = request.getParameter("mother");
        	   String mobile = request.getParameter("mobile");
        	   String email = request.getParameter("email");
        	   String department = request.getParameter("department");
        	   String faculty = request.getParameter("faculty");
        	   String year = request.getParameter("year");
        	   con = DBConnection.getMysqlConnection();
        	   stm = (Statement) con.createStatement();
        	   String query = "insert into student(studID,firstname,lastname,grandfather,mothername,mobile,email,department,faculty,year)"
        	   		        + "values('"+studID+"','"+fname+"','"+lname+"','"+gname+"','"+mother+"','"+mobile+"','"+email+"','"+department+"','"+faculty+"','"+year+"')";
        	   status = stm.executeUpdate(query);
        	   if (status > 0) {
        		session.setAttribute("fname", fname);
				request.setAttribute("message", "Student Added Successfully !!");
                request.getRequestDispatcher("Faculty/register_student.jsp").forward(request, response);
			     }
     			 else{
        		     request.setAttribute("message", "Fail to add Student !!");
       			 } 
           }/*else if(request.getParameter("upload")!=null){
        	   FileInputStream input = new FileInputStream("C:\\Users\\Tolerant\\Documents\\NetBeansProjects\\JavaApplication4\\data.xls");
               POIFSFileSystem fs = new POIFSFileSystem(input);
               HSSFWorkbook wb = new HSSFWorkbook(fs);

               HSSFSheet sheet = wb.getSheetAt(0);
               Row row;
               for (int i = 1; i <= sheet.getLastRowNum(); i++) {

                   row = sheet.getRow(i);
                   String Process = row.getCell(0).getStringCellValue();
                   String Level = row.getCell(1).getStringCellValue();
                   int A = (int) row.getCell(2).getNumericCellValue();


                   String sql = "INSERT INTO csvtable(Fname, Lname, Age) VALUES('" + Process + "','" + Level + "','" + A + "')";
                   stm = (Statement) con.prepareStatement(sql);
                   stm.executeUpdate(sql);
                   System.out.println("Success import excel to mysql table");
               }
           }*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);	
	}

}
