package com.sipas.faculty_dean;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;
import com.sipas.system.PasswordEncryption;

@WebServlet("/deanPassword")
public class ChangePassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public ChangePassword() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException {
    try{
    	PasswordEncryption pe = new PasswordEncryption();
    	String oldDB = "";
    	String page = "";
    	if (request.getParameter("dean")!=null) {
			String oldPass = request.getParameter("old");
			String newPass = request.getParameter("pwd");
			String username = request.getParameter("username");
			 con = DBConnection.getMysqlConnection();
			 stm = (Statement) con.createStatement();
			 result = (ResultSet) stm.executeQuery("select * from sipas_user where username = '"+username+"'");
			 if (result.next()) {
				oldDB = result.getString("password");
				if (pe.Encrypt(oldPass).equals(oldDB)) {
				 String query = "update sipas_user set password = '"+pe.Encrypt(newPass)+"' where username = '"+username+"'";
				 status = stm.executeUpdate(query);
				 if (status>0) {
						request.setAttribute("message", "You Have Successfuly Changed Your PAssword");
						response.setHeader("refresh", "3;profile.jsp");
						page = "profile.jsp";
				}else{

						request.setAttribute("message", "Failed To Change Password");
						response.setHeader("refresh", "3;profile.jsp");
						page = "profile.jsp";
				}
				}else{
					request.setAttribute("message", "You Entere Incorrect Password");
					response.setHeader("refresh", "3;profile.jsp");
					page = "profile.jsp";
				}
			}
			 request.getRequestDispatcher(page).forward(request, response);
		}
    }catch (Exception e) {
    	e.printStackTrace();
	}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

}
