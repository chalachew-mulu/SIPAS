package com.sipas.faculty_dean;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/deanAnnouncement")
public class Announcement extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public Announcement() {
        super();
    }
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 try {
			 write = response.getWriter();
			 session = request.getSession();
		 if (request.getParameter("post")!=null) {
			 String page1 = "";
			 String name = request.getParameter("name");
			 String description = request.getParameter("description");
			 String start = request.getParameter("start");
			 String posted = request.getParameter("posted_by");
			 java.sql.Date Date_posted = new java.sql.Date(new java.util.Date().getTime());
			 String expiry = request.getParameter("expiry");	
			 int sender = Integer.parseInt(request.getParameter("sender"));
			 
			 java.text.DateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy");
	    	    
    	     java.util.Date startDate = format.parse(start);
    	     java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());

    	     java.util.Date endDate = format.parse(expiry);
    	     java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
    	     
			 con = DBConnection.getMysqlConnection();
			 stm = (Statement) con.createStatement();
			 String query = "insert into announcement(name, description,start_date,expiry_date,date_posted,posted_by) values('"+name+"','"+description+"','"+sqlStartDate+"','"+sqlEndDate+"','"+Date_posted+"','"+posted+"')";
			 status = stm.executeUpdate(query);
			 if (status > 0) {
				stm.executeUpdate("insert into notification(sender_id,notification,send_time) values('"+posted+"','"+description+"','"+Date_posted+"')"); 
				session.setAttribute("name", name);
				request.setAttribute("message", "New Announcement Posted !!");
				
				page1 = "Faculty/announcement.jsp";
				response.setHeader("refresh", "2;Faculty/announcement.jsp");
				request.getRequestDispatcher(page1).forward(request, response);
				//response.sendRedirect("Faculty/announcement.jsp");
			 }
			 else{
				 write.println("oops! Something Went Wrong ...");
			 } 
		}
		 else if (request.getParameter("update") != null) {
			 String page2 = ""; 
			 System.out.println("Update Announcement");
			
			 int id = Integer.parseInt(request.getParameter("id"));
			 String name = request.getParameter("name");
			 String description = request.getParameter("description");
			 String start = request.getParameter("start");
			 String posted = request.getParameter("posted");
			 String expiry = request.getParameter("expiry");
			 
			 java.text.DateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy");
	    	    
    	     java.util.Date startDate = format.parse(start);
    	     java.sql.Date sqlStartDate = new java.sql.Date(startDate.getTime());

    	     java.util.Date endDate = format.parse(expiry);
    	     java.sql.Date sqlEndDate = new java.sql.Date(endDate.getTime());
    	     
			 java.sql.Date Date_posted = new java.sql.Date(new java.util.Date().getTime());
			 
			 con = DBConnection.getMysqlConnection();
			 stm = (Statement) con.createStatement();
			 String updateQuery = "update announcement set name='"+name+"',description='"+description+"',start_date='"+sqlStartDate+"',date_posted='"+Date_posted+"',expiry_date='"+sqlEndDate+"' where id = '"+id+"'";
			 
			 status = stm.executeUpdate(updateQuery);
			 if (status > 0) {
				session.setAttribute("name", name);
			    request.setAttribute("message", "Announcement Updated Successfully");
				page2 = "Faculty/editAnnouncement.jsp";
				response.setHeader("refresh", "2;Faculty/announcement.jsp");
			    //response.sendRedirect("Faculty/announcement.jsp");
			}else{
			 write.println("oops! Something Went Wrong ...");	
			}
			 request.getRequestDispatcher(page2).forward(request, response);
		}
	} catch(SQLException | ParseException e) {
		e.printStackTrace();
	}
 }
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
}
