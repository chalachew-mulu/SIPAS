package com.sipas.system;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

@WebServlet("/checkLegiblity")
public class CheckLegiblity extends HttpServlet {
	private static final long serialVersionUID = 1L;
    Connection con = null;
    Statement stm,stm2,stm3 = null;
    ResultSet result = null;
    HttpSession session;
    public CheckLegiblity() {
        super();
    }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    		throws ServletException, IOException{
    	session = request.getSession();
		String fnameDb = "";String lnameDb = "";String gnameDb = "";String studidDb = "";String emailDB;String motherDb = "";
		String page = "";
		String statusDB = "";
    	try {
    	if (request.getParameter("apply")!=null) {
			
    		String fname = request.getParameter("fname");
			String lname = request.getParameter("lname");
			String gname = request.getParameter("gname");
			String mother = request.getParameter("mother");
			String studID = request.getParameter("studID");
			//String faculty = request.getParameter("faculty");
			//String department = request.getParameter("department");
			//String year  = request.getParameter("year");
			String email = request.getParameter("email");
			
			con = DBConnection.getMysqlConnection();
			stm = (Statement) con.createStatement();
			result = (ResultSet) stm.executeQuery("select * from student");
			while (result.next()) {
				fnameDb = result.getString("firstname");
				lnameDb = result.getString("lastname");
				gnameDb = result.getString("grandfather");
				motherDb = result.getString("mothername");
				studidDb = result.getString("studID");
				statusDB = result.getString("status");
				//facultyDb = result.getString("faculty");
				//departmentDb = result.getString("department");
				emailDB = result.getString("email");
				//yearDb = result.getString("year");
				if (fname.equals(fnameDb)&&lname.equals(lnameDb)&&
				    gname.equals(gnameDb)&&mother.equals(motherDb)&&
					studID.equals(studidDb)&&email.equals(emailDB) && statusDB.equals("Active")) 
				    {	
					   RandomPassword rand = new RandomPassword(); 
					   String temp = rand.generateRandomPassword();
					   PasswordEncryption hash = new PasswordEncryption();	
					   System.out.println(temp);
					   stm2 = (Statement) con.createStatement();
					   String query = "update student set username='"+studID+"',password='"+hash.Encrypt(temp)+"' where studID='"+studID+"'";
					   int update = stm2.executeUpdate(query);
					   
					   if(update > 0)
					   {
						   session.setAttribute("studID", studID);
						   session.setAttribute("fname", fname);
						   session.setAttribute("lname", lname);
		                    page = ("/apply.jsp");
					   }
					   /*
					    Properties p = new Properties();
					    p.put("mail.smtp.auth","true");
					    p.put("mail.smtp.starttls.enable",true);
					    p.put("mail.smtp.host","smtp.gmail.com");
					    
					    String myaccountemail = "chalachewmulu@gmail.com";
					    String password = "taLL@@12";
					    
					    Session session = Session.getInstance(p, new Authenticator() {
					    @Override
					    protected PasswordAuthentication getPasswordAuthentication(){
					        return new PasswordAuthentication(myaccountemail, password);
					    }
					    });
					    Message message = new MimeMessage(session);
				   	    message.setFrom(new InternetAddress(myaccountemail));
				   	    message.setRecipient(Message.RecipientType.TO, new InternetAddress(email));
				   	    message.setSubject(fname+" Login Password");
				   	    message.setText("Hi; " +fname.toUpperCase()+ " your password is!. "+temp);
					    Transport.send(message);

					    System.out.println("Message sent seccessfully");
	                    */
	                    page = ("/apply.jsp");
	                 
				  }
				/*else{

					request.setAttribute("message", "You are not Ligible");
					page = "home.jsp";
					response.setHeader("refresh", "3;home.jsp");
					
					//page = "home.jsp";
				}*/
		  }
			request.getRequestDispatcher(page).forward(request, response);
         }
    	} catch (Exception e) {
			e.printStackTrace();
	   }
      }
   	@Override
   	protected void doGet(HttpServletRequest request, HttpServletResponse response)
   	throws ServletException, IOException{
   		processRequest(request, response);
   	}
   	@Override
   	protected void doPost(HttpServletRequest request, HttpServletResponse response)
   	throws ServletException, IOException{
   		processRequest(request, response);
   	}

}
