package com.sipas.coordinator;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;
import com.sipas.system.PasswordEncryption;

@WebServlet("/manageSupervisor")
public class ManageUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PrintWriter write;
	Connection con;
	Statement stm;
	ResultSet rs;
	HttpSession session;
	int status = 0;
    public ManageUser() {
        super();
    }
    public void processRequest(HttpServletRequest request, HttpServletResponse response) 
    		throws ServletException, IOException{
    	session = request.getSession();
    	write = response.getWriter();
    	try {
    		
			if(request.getParameter("register")!=null){
				String role = request.getParameter("role");
				String name = request.getParameter("name");
				String username = request.getParameter("username");
				String password = request.getParameter("pwd");
				
				PasswordEncryption pe = new PasswordEncryption();
				
				con = DBConnection.getMysqlConnection();
				stm = (Statement) con.createStatement();
				String query="";
				if(role.equals("Supervisor"))
				{
				 query = "insert into sipas_user(role, username, password, status, super_id) "
						+ "values('"+role+"','"+username+"','"+pe.Encrypt(password)+"','Active','"+name+"')";
				}
				 status = stm.executeUpdate(query);
				if (status > 0) {
					session.setAttribute("username", username);
					request.setAttribute("message", "User Added Sucessfuly !!");
					request.getRequestDispatcher("Coordinator/manage_user.jsp").forward(request, response);
				}else{
					request.setAttribute("message", "Failed t Add User");
					request.getRequestDispatcher("Coordinator/manage_user.jsp").forward(request, response);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	processRequest(request, response);	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
	processRequest(request, response);
	}

}
