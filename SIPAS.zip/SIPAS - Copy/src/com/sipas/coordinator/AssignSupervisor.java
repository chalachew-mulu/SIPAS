package com.sipas.coordinator;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/assignSupervisor")
public class AssignSupervisor extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	ResultSet rs;
	Statement stm,stm2,stm3;
	int status = 0;
	public AssignSupervisor() {
        super();
     }
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
			String page = "";		
		try{	
	if(request.getParameter("assign")!=null){
		 
				 String [] student  = request.getParameterValues("student");
				 String supervisor    =  request.getParameter("super"); 
			     java.sql.Timestamp date_assigned = new java.sql.Timestamp(new java.util.Date().getTime());
				 con = DBConnection.getMysqlConnection();
				 stm = (Statement) con.createStatement();
			
		    for (String i : student) { 			
				  String query = "insert into coordinator_assign_supervisor(supervisor_id, student_id, date_assigned) values('"+supervisor+"','"+i+"','"+date_assigned+"')";
				  status = stm.executeUpdate(query);
			//if (status > 0) {
	   			  //stm2 = (Statement) con.createStatement();
	   			  //String updateQuery = "update internship_request set is_supervisor_assigned='yes' where student_id = '"+i+"' and ac_status='1'";
	   			 
	   			 // stm3 = (Statement) con.createStatement();
	   			  //String updateQuery2 = "update supervisor set is_assigned_for_student='yes' where super_id = '"+supervisor+"'";
	   			 
	   			  //status = stm2.executeUpdate(updateQuery);
	   			  //status = stm2.executeUpdate(updateQuery2);
				  if(status > 0){
					  stm.executeUpdate("insert into supervisor_notify (super_id, student_id, date_assigned) values('"+supervisor+"','"+i+"','"+date_assigned+"')");

					  request.setAttribute("message", "Supervisor Assigned Success !!");
					  page = "Coordinator/assign_supervisor.jsp";
					  response.setHeader("refresh", "2;Coordinator/assign_supervisor.jsp");
				  }else{
					  request.setAttribute("message", "Supervisor Assigned Failed !!");
					  page = "Coordinator/assign_supervisor.jsp";
					  response.setHeader("refresh", "2;Coordinator/assign_supervisor.jsp");
				  }
			     }
			  // } 
		       request.getRequestDispatcher(page).forward(request, response);
           }
         }catch (Exception e) {
    	 e.printStackTrace();
	 }
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
     processRequest(request, response);	
		}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
      processRequest(request, response);
	}
	

}
