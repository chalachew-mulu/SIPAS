package com.sipas.coordinator;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/registerSupervisor")
public class RegisterSupervisor extends HttpServlet {
	private static final long serialVersionUID = 1L;
    PrintWriter write;
    HttpSession session;
    int status = 0;
    Connection con;
    Statement stm;
    ResultSet result;
    public RegisterSupervisor() {
        super();
     }    
  public void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {   
		 write = response.getWriter();
		 session = request.getSession();
		 String page = "";
        try {
            if(request.getParameter("register")!=null ) {
            	String super_id = request.getParameter("superID");
        		String fname = request.getParameter("fname");
        		String lname = request.getParameter("lname");
        		String mobile = request.getParameter("mobile");
        		String email = request.getParameter("email");
        		String qualify = request.getParameter("qualify");
        		int company = Integer.parseInt(request.getParameter("company"));
   			 con = DBConnection.getMysqlConnection();
   			 stm = (Statement) con.createStatement();
   			 String query = "insert into supervisor(super_id, firstname,lastname,email,mobile,qualification,comp_id)"
   			 		        + " values('"+super_id+"','"+fname+"','"+lname+"','"+email+"','"+mobile+"','"+qualify+"','"+company+"')";
   			 status = stm.executeUpdate(query);
   			 if (status > 0) {
   				session.setAttribute("fname", fname);
   				request.setAttribute("alertMessage", "Supervisor Added Successfuly!!");
   				page = "Coordinator/register_supervisor.jsp";
                //request.getRequestDispatcher("Coordinator/register_supervisor.jsp").forward(request, response);
                response.setHeader("refresh", "3;Coordinator/register_supervisor.jsp");
   			 }
   			 else{
    		     request.setAttribute("alertMessage", "Failed to Add Supervisor !!");
   			 } 
   			request.getRequestDispatcher(page).forward(request, response); 
   		}
 
	      } catch (Exception e) {
          e.printStackTrace();
		}
	}
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{
		processRequest(request, response);
	}
}
