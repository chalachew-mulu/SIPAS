package com.sipas.coordinator;
import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.mysql.jdbc.ResultSet;
import com.mysql.jdbc.Statement;
import com.sipas.connection.DBConnection;

@WebServlet("/internRequest")
public class ProcessRequest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement stm;
	ResultSet rs,rs2;
	HttpSession sesssion;
	int status = 0;
       public ProcessRequest() {
        super();
        }
	   protected void processRequest(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		sesssion = request.getSession();
		String page = "";
		try {
			int reserved = 0;
			int capacity = 0;
			int cid = Integer.parseInt(request.getParameter("compID"));
			String sid = request.getParameter("studID");
			if (request.getParameter("accept")!=null) {				
				con = DBConnection.getMysqlConnection();
				Statement stm1 = (Statement) con.createStatement();
	 	        rs2 = (ResultSet) stm1.executeQuery("select count(ac_status) from internship_request where student_id='"+sid+"' and ac_status='1'");
	 	        int count = 0;
	 	        while (rs2.next()) {
				 count = count+rs2.getInt(1);	
				}
	 	        if (count > 0) {
					request.setAttribute("message", "This Student have already got an acceptance !!");
		    		page = "Coordinator/process_request.jsp";
		    		response.setHeader("refresh", "2;Coordinator/internship_request.jsp");
	 	        } else{
	 	        	String date_responsed = new java.sql.Timestamp(new java.util.Date().getTime()).toString();
					con = DBConnection.getMysqlConnection();
					stm = (Statement) con.createStatement();
					String query = "update internship_request set ac_status = '1',date_responsed = '"+date_responsed+"' where student_id = '"+sid+"' and comp_id='"+cid+"'";
				    status = stm.executeUpdate(query);
				    if (status > 0) {
				    	String query1 = "delete from internship_request where student_id='"+sid+"' and ac_status = '2' or ac_status='3'";
				    	stm.executeUpdate(query1);
				    	rs = (ResultSet) stm.executeQuery("select capacity, reserved from company where id = '"+cid+"'");
				    	while (rs.next()) {
						 reserved = rs.getInt("reserved");	
						 capacity = rs.getInt("capacity");
						}
				    	if(capacity > reserved){
					    	int reserve = reserved+1;
					    	String quer = "update company set reserved = '"+reserve+"' where id = '"+cid+"'";
					    	stm.executeUpdate(quer);
					    	request.setAttribute("message", "Student Request Accepted !!");
					    	page = "Coordinator/process_request.jsp";	
					    	response.setHeader("refresh", "2;Coordinator/internship_request.jsp");
				    	}
				    	else{
				    		request.setAttribute("message", "Company Capacitance Reached !!");
				    		page = "Coordinator/process_request.jsp";
				    		response.setHeader("refresh", "2;Coordinator/internship_request.jsp");
				    	}
					}	

				}
			    	request.getRequestDispatcher(page).forward(request, response);
			} else if(request.getParameter("reject")!=null) {
				 
				 request.getParameter("StudID");
				 String date_responsed = new java.sql.Timestamp(new java.util.Date().getTime()).toString();
                 con = DBConnection.getMysqlConnection();
                 stm = (Statement) con.createStatement();
                 System.out.println(date_responsed);
                 String query2 = "update internship_request set ac_status='3', date_responsed = '"+date_responsed+"' where student_id = '"+sid+"' and comp_id='"+cid+"'";
                 status = stm.executeUpdate(query2);
                 if (status > 0) {
                	request.setAttribute("message", "Request Rejected !!"); 
					page = "Coordinator/process_request.jsp";
		    		response.setHeader("refresh", "2;Coordinator/internship_request.jsp");

				}
               request.getRequestDispatcher(page).forward(request, response);  
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        processRequest(request, response);
	}

}
