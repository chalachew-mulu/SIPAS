package com.sipas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.ResultSet;
import com.sipas.bean.UILmanageUserBean;
import com.sipas.connection.DBConnection;

public class UILmanageUserDao {
Connection con = null;
PreparedStatement stm =null;
ResultSet rs = null;
public UILmanageUserDao(){
}
public boolean addUser(UILmanageUserBean user){
	boolean adduser  = false;
	Connection con =  DBConnection.getMysqlConnection();
	System.out.println("Connection is Created"+con);
	String sqlQuery = "insert into sipas_user(user_role_id, username, password, status, name) values(?,?,?,?,?)";
	try {
		stm = con.prepareStatement(sqlQuery);
		stm.setString(1, user.getUserRole());
		stm.setString(2, user.getFullname());
		stm.setString(3, user.getUsername());
		stm.setString(4, user.getPassword());
		stm.setString(5, user.getStatus());		
		int rowAffected = stm.executeUpdate();
		if (rowAffected>0) {
			adduser = true;
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	    return adduser;
}
public List<UILmanageUserBean> listUser() {
	List<UILmanageUserBean> list = new ArrayList<>();
	Connection con =  DBConnection.getMysqlConnection();
	String sqlQuery = "select * from sipas_user user, sipas_user_role role where user.user_role_id = role.id";
	try {
		stm = con.prepareStatement(sqlQuery);
		rs = (ResultSet) stm.executeQuery();
		while (rs.next()) {
		String role = rs.getString("role");	
		String name = rs.getString("name");
		String password = rs.getString("password");
		String username = rs.getString("username");
		String status = rs.getString("status");
		UILmanageUserBean user = new UILmanageUserBean(role,username,password,status,name);
		list.add(user);
		}
	}
	catch (Exception e) {
		
	}
   return list;
}
}
