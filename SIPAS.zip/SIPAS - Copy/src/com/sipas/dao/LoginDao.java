package com.sipas.dao;
 

import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
import com.sipas.bean.LoginBean;
import com.sipas.connection.DBConnection;
import com.sipas.system.PasswordEncryption;
 
public class LoginDao {
public String authenticateUser(LoginBean loginBean) throws NoSuchAlgorithmException
{	
 String passwordSelected = null;
 String userName = loginBean.getUserName();
 String password = loginBean.getPassword();
 
 Connection con = null;
 Statement statement = null;
 ResultSet resultSet = null;
 
 String userNameDB = "";
 String passwordDB = "";
 String roleDB = "";
 
 //String passHash = hashPassword(password);

 PasswordEncryption pe = new PasswordEncryption();
 
 System.out.println(passwordSelected);
 try
 {	  	 
 con = DBConnection.getMysqlConnection();
 statement = con.createStatement();
 resultSet = statement.executeQuery("select * from sipas_user");

 while(resultSet.next())
 {	 
 userNameDB = resultSet.getString("username");
 passwordDB = resultSet.getString("password");
 roleDB = resultSet.getString("role");
 
 if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("admin"))
     return "Admin_Role";
 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Faculty"))
     return "Faculty_Role";
 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("student"))
     return "Student_Role";
 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Advisor"))
	 return "Advisor_Role";
 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Coordinator"))
	 return "Coordinator_Role";
 else if(userName.equals(userNameDB) && pe.Encrypt(password).equals(passwordDB) && roleDB.equals("Supervisor"))
	 return "Supervisor_Role";
 }
 }
 catch(SQLException e)
 {
 e.printStackTrace();
 }
 return "Invalid Username or Password !!";
}
}