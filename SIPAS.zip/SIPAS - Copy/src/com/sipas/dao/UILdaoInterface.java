/*package com.sipas.dao;
/*package com.sipas.dao;
import java.util.List;

import com.sipas.bean.UILManageFacultyDeanBean;

public interface UILDaoInterface {
	public boolean addFacultyDean(UILManageFacultyDeanBean faculty);
	public List<UILManageFacultyDeanBean> listFacultyDean();
	public UILManageFacultyDeanBean getFacultyDeanID(int id);
	public boolean updateFaculty(UILManageFacultyDeanBean faculty);
}


*/