package com.sipas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sipas.connection.DBConnection;
import com.sipas.bean.UILmanageFacultyDeanBean;

public class UILmanageFacultyDeanDao {
	Connection con = null;
	PreparedStatement stm = null;
	java.sql.ResultSet rs = null;
	public UILmanageFacultyDeanDao(){
	}
	public boolean addFacultyDean(UILmanageFacultyDeanBean faculty){
		boolean addFacultydean  = false;
		Connection con =  DBConnection.getMysqlConnection();
		System.out.println("Connection is Created"+con);
		String sqlQuery = "insert into faculty_dean(facultyDeanID, firstname, lastname, email, mobile, officeNumber, faculty) values(?,?,?,?,?,?,?)";
		try {
			stm = con.prepareStatement(sqlQuery);
			stm.setString(1, faculty.getFacultyDeanID());
			stm.setString(2, faculty.getFirstname());
			stm.setString(3, faculty.getLastname());
			stm.setString(4, faculty.getEmail());
			stm.setString(5, faculty.getOfficeNumber());
			stm.setString(6, faculty.getMobile());
			stm.setString(7, faculty.getFaculty());
			
			int rowAffected = stm.executeUpdate();
			if (rowAffected>0) {
				addFacultydean = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		    return addFacultydean;
	}
	public List<UILmanageFacultyDeanBean> listFacultyDean() {
		List<UILmanageFacultyDeanBean> list = new ArrayList<>();
		Connection con =  DBConnection.getMysqlConnection();
		String sqlQuery = "select * from faculty_dean";
		try {
			stm = con.prepareStatement(sqlQuery);
			rs = stm.executeQuery();
			while (rs.next()) {
			int id  = rs.getInt("id");
			String fname = rs.getString("firstname");
			String lname = rs.getString("lastname");
			String fid = rs.getString("facultyDeanID");
			String mobile = rs.getString("mobile");
			String email = rs.getString("email");
			String faculty = rs.getString("faculty");
			String office = rs.getString("officeNumber");
			UILmanageFacultyDeanBean facultyDean = new UILmanageFacultyDeanBean(id,  fid,  fname, lname, email, mobile, office, faculty);
			list.add(facultyDean);
			}
		}
		catch (Exception e) {
			
		}
	   return list;
	}
	public UILmanageFacultyDeanBean getFacultyDeanID(int id) {
		UILmanageFacultyDeanBean facultyDean = null;
		Connection con =  DBConnection.getMysqlConnection();
		System.out.println("Connection is Created"+con);
		String sqlQuery = "select * from faculty_dean where id = ?";
		try {
			stm = con.prepareStatement(sqlQuery);
			stm.setInt(1, id);
			rs = stm.executeQuery();
			while (rs.next()) 
			{ 
			int id1  = rs.getInt("id");
			String fname = rs.getString("firstname");
			String lname = rs.getString("lastname");
			String fid = rs.getString("facultyDeanID");
			String mobile = rs.getString("mobile");
			String email = rs.getString("email");
			String faculty = rs.getString("faculty");
			String office = rs.getString("officeNumber");
			
			facultyDean = new UILmanageFacultyDeanBean(id1,  fid,  fname, lname, email, mobile, office, faculty);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return facultyDean;
	}
	public boolean updateFaculty(UILmanageFacultyDeanBean faculty) {
		boolean updateStatus = false;
		Connection con =  DBConnection.getMysqlConnection();
		System.out.println("Connection is Created"+con);
		String sqlQuery = "update faculty_dean set facultyDeanID=?, firstname=?,lastname=?, email=?, mobile=?, faculty=?, officeNumber=? where id = ?";
		try {
			stm = con.prepareStatement(sqlQuery);
			stm.setString(1, faculty.getFacultyDeanID());
			stm.setString(2, faculty.getFirstname());
			stm.setString(3, faculty.getLastname());
			stm.setString(4, faculty.getEmail());
			stm.setString(5, faculty.getMobile());
			stm.setString(6, faculty.getFaculty());
			stm.setString(7, faculty.getOfficeNumber());
			stm.setInt(8, faculty.getId());
		
			int rowAffected = stm.executeUpdate();
			if (rowAffected>0) {
			 updateStatus = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return updateStatus;
	}	
}