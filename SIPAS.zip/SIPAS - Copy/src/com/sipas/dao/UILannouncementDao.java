package com.sipas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.mysql.jdbc.ResultSet;
import com.sipas.bean.UILannouncementBean;
import com.sipas.connection.DBConnection;

public class UILannouncementDao {
Connection con = null;
PreparedStatement stm = null;
ResultSet result = null;
public boolean addAnnouncement(UILannouncementBean announcement){
	boolean addAnnoucement = false;
	 con = DBConnection.getMysqlConnection();
	 String query = "insert into announcement(name, description, start_date, expiry_date, date_posted) values (?,?,?,?,?)";
	 try {
		stm = con.prepareStatement(query);
	    stm.setString(1, announcement.getName());
	    stm.setString(2, announcement.getDescription());
	    stm.setDate(3, (Date) announcement.getStartDate());
	    stm.setDate(4, (Date) announcement.getEndDate());
	    stm.setDate(5, (Date) announcement.getDatePosted());
	   
	    int recordAdded = stm.executeUpdate();
	    if (recordAdded > 0) {
			addAnnoucement=true;
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return addAnnoucement;	
}
}
