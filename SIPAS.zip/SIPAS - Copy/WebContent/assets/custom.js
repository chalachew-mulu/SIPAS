   $(document).ready(function(){
   $("#addCompany").click(function(){
    $("#company_form").toggle();
    $("#view_company").hide();
    $("#add_company").show();
    $("#btn_company").hide();
    $("#compant_table").toggle();
    $("#list").hide();
    $("#plus").show();
  })
  $("#cancel").click(function(){
    $("#company_form").toggle();
    $("#btn_company").show();
    $("#compant_table").toggle();
    $("#view_company").show();
    $("#add_company").hide();
    $("#list").show();
    $("#plus").hide();
  })
  $("#submit").click(function(){
	  $("#myAlert-top").show(); 
	  setTimeout(function(){
	    $("#myAlert-top").hide(10000);
      }, 4000);
  })
  });
   